TESTVAR=/path1/sub1:/path2/sub2
export TESTVAR
