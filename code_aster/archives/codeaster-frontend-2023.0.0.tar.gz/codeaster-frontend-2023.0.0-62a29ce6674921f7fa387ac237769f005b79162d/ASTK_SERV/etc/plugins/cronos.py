# -*- coding: utf-8 -*-

"""
This module allows to adjust some parameters according to
the type of execution.

These asrun customizations are called through (in asrun configuration file) :

    schema_calcul : plugins.<module-name>.modifier
"""

import os

from asrun.core import magic
from asrun.plugins.generic_func import getCpuParameters, setDistrLimits


# memory (MB) added to memjob for testcases
MEMSUP = 0


def modifier(calcul):
    """Call elementary functions to adjust :
        - batch parameters,
    Argument : ASTER_CALCUL object
    Return value : ASTER_PROFIL object."""
    serv = calcul.serv
    prof = calcul.prof
    if prof["mode"][0] == "batch":
        prof = change_batch_parameters(serv, prof)
    setDistrLimits(prof, 512, 3 * 24 * 3600 - 1, "batch")
    return prof


def getCpuParametersLocal(prof):
    """Force to use all available threads for OpenMP AND Blas.
    See `asrun.plugins.generic_func.getCpuParameters` function."""
    # Fix the number of physical processors (2) & cores per processor (24).
    cpu_mpi, node_mpi, cpu_openmp, blas_thread = getCpuParameters(2, 24, prof)
    cpu_openmp = cpu_openmp * blas_thread
    return cpu_mpi, node_mpi, cpu_openmp, blas_thread


def change_batch_parameters(serv, prof):
    """Change the batch parameters in an export object (classe...)."""
    cpu_mpi, node_mpi, cpu_openmp, blas_thread = getCpuParametersLocal(prof)
    cpu_per_node = cpu_mpi / node_mpi

    # change job queue if :
    #  - it's a study and the batch queue is not defined
    #  - or it's a testcase.
    batch_custom = ""
    if "astout" in prof["actions"]:
        prof["memjob"] = 1000 * 1024
        prof["tpsjob"] = 60 * 24
    if node_mpi > 1 or cpu_mpi >= 6:
        batch_custom += " --exclusive"
    if cpu_mpi > 1:
        # try to activate exclusive mode only with several nodes
        # batch_custom += ' --exclusive'
        # --nodes is now required, even if it is equal to 1
        if not prof["mpi_nbnoeud"][0]:
            prof["mpi_nbnoeud"] = 1
    else:
        # --nodes must not be set in sequential
        if prof["mpi_nbnoeud"][0]:
            prof["mpi_nbnoeud"] = ""

    memory_limit = float(prof["memjob"][0]) / 1024.0
    prof.set_param_memory(memory_limit)

    DEFAULT_QUEUE = "bm"
    # memory per node in GB
    memGB = memory_limit * cpu_per_node / 1024.0
    if memGB < 64:  # 192 GB available on nodes but without disk
        DEFAULT_QUEUE = "cn"
    # with this filter, we do not use cn nodes with 384 GB
    if memGB > 300:  # for 384 GB and 768 GB nodes
        DEFAULT_QUEUE = "bm"
    if memGB > 700:  # for 6 TB
        DEFAULT_QUEUE = "tm"

    g0 = group = prof["classe"][0]
    if group == "":
        group = DEFAULT_QUEUE

    # adjust memoryNode
    prof["memoryNode"] = memory_limit * cpu_per_node * 1.1
    if group == "cn":
        prof["memoryNode"] = (memGB + 96) * 1024
    if group == "bm":
        if "--exclusive" in batch_custom:
            if memGB < 300:  # up to 384 GB
                prof["memoryNode"] = 350 * 1024
            else:
                prof["memoryNode"] = 720 * 1024
    if group == "tm":
        if "--exclusive" in batch_custom:
            prof["memoryNode"] = 5900 * 1024

    if not magic.run.get("batch_wckey"):
        batch_custom += " --wckey=P11YB:ASTER"

    # time limit in hour
    tpsjob = float(prof["tpsjob"][0]) * 60.0 / 3600.0

    # special hook for performance testcases with 1 cpu
    if cpu_mpi == 1 and "performance" in prof["testlist"][0] and memGB < 64:
        batch_custom += " --exclusive"

    # allocate all the available cores if not given in export
    if not prof["ncpus"][0]:
        # prof['ncpus'] = min([6, cpu_openmp])
        prof["ncpus"] = 1
        magic.run.DBG("Change number of threads: %s" % prof["ncpus"][0])

    prof["ncpus"] = int(prof["ncpus"][0])

    # general - see https://computing.llnl.gov/linux/slurm/cpu_management.html

    batch_custom += (
        " --cpus-per-task={0} --threads-per-core=1 "
        "--distribution=block:block "
        "--mem-bind=local"
    ).format(prof["ncpus"][0])

    prof["batch_custom"] = batch_custom
    if group != g0:
        prof["classe"] = group
        magic.run.DBG("Change batch queue group to : %s" % group)
    return prof
