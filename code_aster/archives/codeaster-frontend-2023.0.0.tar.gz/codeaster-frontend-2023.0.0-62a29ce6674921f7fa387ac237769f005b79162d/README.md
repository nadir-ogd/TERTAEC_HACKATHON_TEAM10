# codeaster-frontend

This repository provides the legacy code_aster frontend, named **astk**
and the backend **asrun** used by **astk** and **asterstudy**.

> NB: If you want to call code_aster from scripts, you should use **bin/run_aster**
> from your code_aster installation instead of **asrun**.

To install asrun, just type:

```shell
python setup.py install --prefix=ASTER_ROOT
```

Typically, `ASTER_ROOT=/opt/aster` or similar.

To run unittest:

- on a functionnal installation:

  ```shell
  cd $ASTER_ROOT/share/codeaster/asrun/unittest
  run_test.py --all
  ```

- on a source repository :

    1. install asrun in a test directory (for example `/tmp/test`):

       ```shell
       export ASTER_ROOT=/tmp/test
       python setup.py install --prefix=$ASTER_ROOT
       ```

    2. configure the files in `$ASTER_ROOT/etc/codeaster`, for example
       by copying them from a working installation and use a working
       version of *Code_Aster*:

       ```shell
       cd $ASTER_ROOT/etc/codeaster
       cp /opt/aster/etc/codeaster/* .
       cd $ASTER_ROOT
       ln -s /opt/aster/NEW11 .
       ```

       If you copied the files, do not forget to change `ASTER_ROOT`
       to `/tmp/test`:

       ```shell
       cd $ASTER_ROOT/etc/codeaster
       vi asrun
       ```

    3. run testcases:

       ```shell
       cd $ASTER_ROOT/share/codeaster/asrun/unittest
       run_test.py --all
       ```
