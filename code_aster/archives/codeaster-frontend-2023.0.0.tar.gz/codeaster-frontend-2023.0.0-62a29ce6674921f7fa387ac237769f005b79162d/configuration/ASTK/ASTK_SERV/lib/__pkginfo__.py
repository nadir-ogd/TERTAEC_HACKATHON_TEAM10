"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.__pkginfo__', DeprecationWarning, stacklevel=2)
from asrun.__pkginfo__ import *
