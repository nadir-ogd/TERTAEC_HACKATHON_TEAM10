"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.astout', DeprecationWarning, stacklevel=2)
from asrun.astout import *
