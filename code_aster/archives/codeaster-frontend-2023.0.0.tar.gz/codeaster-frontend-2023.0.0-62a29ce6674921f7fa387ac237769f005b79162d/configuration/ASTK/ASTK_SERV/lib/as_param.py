"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.parametric', DeprecationWarning, stacklevel=2)
from asrun.parametric import *
