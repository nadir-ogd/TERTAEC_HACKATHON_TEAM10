"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.mpi', DeprecationWarning, stacklevel=2)
from asrun.mpi import *
