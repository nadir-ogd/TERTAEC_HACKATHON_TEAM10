"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.profil', DeprecationWarning, stacklevel=2)
from asrun.profil import *
