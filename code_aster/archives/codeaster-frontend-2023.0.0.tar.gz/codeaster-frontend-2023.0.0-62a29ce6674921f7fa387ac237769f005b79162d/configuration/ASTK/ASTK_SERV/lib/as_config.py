"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.config', DeprecationWarning, stacklevel=2)
from asrun.config import *
