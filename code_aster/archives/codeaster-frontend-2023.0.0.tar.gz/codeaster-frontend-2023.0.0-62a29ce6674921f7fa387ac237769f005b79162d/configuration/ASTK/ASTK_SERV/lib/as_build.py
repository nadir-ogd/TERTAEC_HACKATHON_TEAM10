"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.build', DeprecationWarning, stacklevel=2)
from asrun.build import *
