"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.N__F', DeprecationWarning, stacklevel=2)
from asrun.N__F import *
