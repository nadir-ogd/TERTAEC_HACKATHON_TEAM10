"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.backward_compatibility', DeprecationWarning, stacklevel=2)
from asrun.backward_compatibility import *
