"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.services', DeprecationWarning, stacklevel=2)
from asrun.services import *
