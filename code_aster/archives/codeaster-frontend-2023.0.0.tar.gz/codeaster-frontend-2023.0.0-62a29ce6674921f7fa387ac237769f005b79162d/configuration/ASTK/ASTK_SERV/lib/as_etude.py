"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.bddetudes', DeprecationWarning, stacklevel=2)
from asrun.bddetudes import *
