"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.update', DeprecationWarning, stacklevel=2)
from asrun.update import *
