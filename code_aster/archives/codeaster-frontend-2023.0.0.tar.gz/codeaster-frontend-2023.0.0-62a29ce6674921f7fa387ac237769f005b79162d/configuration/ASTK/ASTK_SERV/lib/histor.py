"""pre 1.8 backward compatibility"""
from warnings import warn
warn('moved to asrun.histor', DeprecationWarning, stacklevel=2)
from asrun.histor import *
