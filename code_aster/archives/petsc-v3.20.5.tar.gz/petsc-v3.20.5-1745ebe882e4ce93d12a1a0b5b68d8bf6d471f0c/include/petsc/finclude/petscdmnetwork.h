!
!  Include file for Fortran use of the DMNetwork
!
#if !defined (PETSCDMNETWORKDEF_H)
#define PETSCDMNETWORKDEF_H

#define DMNetworkMonitor PetscFortranAddr

#endif
