!
!  Single Fortran include file for all of PETSc
!

#include "petsc/finclude/petscsys.h"
#include "petsc/finclude/petscdraw.h"
#include "petsc/finclude/petscviewer.h"
#include "petsc/finclude/petscbag.h"
#include "petsc/finclude/petscis.h"
#include "petsc/finclude/petscvec.h"
#include "petsc/finclude/petscmat.h"
#include "petsc/finclude/petscdm.h"
#include "petsc/finclude/petscdmda.h"
#include "petsc/finclude/petscdmplex.h"
#include "petsc/finclude/petscdmlabel.h"
#include "petsc/finclude/petscpc.h"
#include "petsc/finclude/petscksp.h"
#include "petsc/finclude/petscsnes.h"
#include "petsc/finclude/petscts.h"
