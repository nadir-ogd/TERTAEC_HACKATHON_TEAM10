=============================
Data Layout and Communication
=============================

.. toctree::
   :maxdepth: 1

   PetscSF/index
   PetscSection/index
   AO/index
