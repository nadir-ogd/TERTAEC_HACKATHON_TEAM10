============
Optimization
============

.. toctree::
   :maxdepth: 1

   Tao/index
   TaoLineSearch/index
