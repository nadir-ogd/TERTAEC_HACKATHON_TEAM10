
=========================================
Documentation for previous PETSc releases
=========================================

.. toctree::
  :maxdepth: 1

   3.19 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.19/docs>
   3.18 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.18/docs>
   3.17 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.17/docs>
   3.16 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.16/docs>
   3.15 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.15/docs>
   3.14 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.14/docs>
   3.13 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.13/docs>
   3.12 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.12/docs>
   3.11 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.11/docs>
   3.10 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.10/docs>
   3.9 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.9/docs>
   3.8 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.8/docs>
   3.7 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.7/docs>
   3.6 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.6/docs>
   3.5 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.5/docs>
   3.4 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.4/docs>
   3.3 <https://web.cels.anl.gov/projects/petsc/vault/petsc-3.3/docs>

