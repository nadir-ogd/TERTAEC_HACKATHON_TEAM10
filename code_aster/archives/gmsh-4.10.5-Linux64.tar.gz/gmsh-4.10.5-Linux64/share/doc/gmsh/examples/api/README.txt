This directory contains examples written using the Gmsh Application Programming
Interface (API), in C++, C, Python and Julia.

To learn how to use the Gmsh API, first check out the
`gmsh/tutorials/{c++,c,python,julia}' directories, which contain the C++, C,
Python and Julia API tutorials, as well as detailed instructions on how to run
them.
