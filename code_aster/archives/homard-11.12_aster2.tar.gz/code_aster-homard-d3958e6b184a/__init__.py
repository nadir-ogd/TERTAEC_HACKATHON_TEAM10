# -*- coding: iso-8859-1 -*-
"""
Programme d'installation de HOMARD

Copyright EDF-R&D 2004, 2011
"""
__revision__ = "V1.1"
#
