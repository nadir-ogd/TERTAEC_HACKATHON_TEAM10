# -*- coding: utf-8 -*-
"""
Programme d'installation de HOMARD

Copyright EDF 2004, 2005, 2006, 2014, 2015
"""
#
__revision__ = "V2.19"
#
import os
import tempfile
#
L_OUI = [ "o", "oui", "y", "yes" ]
L_NON = [ "n", "non", "no" ]
#
#========================= Debut de la fonction ===================================
#
def question (nomfic, texte) :
#
  """
  nomfic : nom du fichier a supprimer
  texte : texte de la question
  question sur la suppresion d'un fichier ou d'un repertoire
  code de retour : 0 : le fichier/repertoire est a conserver
                   1 : le fichier/repertoire est a supprimer
  """
#
  #print "\nArguments a l'entree de", __name__, ":"
  #print "\nnomfic   :", nomfic
#
  if os.path.isdir(nomfic) :
    message0 = "Le repertoire "
  else :
    message0 = "Le fichier "
  message0 += nomfic + " existe.\n"
  message0 += texte + " ? (y/n)\n"
#
  encore = 1
#
  while encore :
#
    reponse = raw_input(message0)
#
    if len(reponse) > 0 :
#
      if reponse in L_OUI :
        encore = 0
        a_tuer = 1
        break
#
      elif reponse in L_NON :
        encore = 0
        a_tuer = 0
        break
#
  return a_tuer
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def tue_fic_option (nomfic, texte, force, verbose, verbose_max) :
#
  """
  nomfic : nom du fichier a supprimer
  texte : texte de la question
  force = 0 : avec une question
  force = 1 : obligatoirement
  code de retour : 0 : le fichier a ete supprime
                  -1 : le fichier est conserve
                   2 : erreur a la destruction
  """
#
  if verbose_max :
    print ("\nArguments a l'entree de", __name__, ":")
    print ("\nnomfic   :", nomfic)
#
  message = None
  erreur = 0
#
  if force :
    a_tuer = 1
  else :
    a_tuer = question(nomfic, texte)
#
  if a_tuer :
#
    erreur = 0
#
    if not os.path.islink(nomfic) :
      err = [0]
      try :
        os.chmod  (nomfic, 0o755)
      except os.error as err :
        message  = "fichier " + nomfic
        message += "\nProbleme au chmod, erreur numero ", err[0], ":", err[1]
        erreur = 5
#
    err = [0]
    try :
      os.remove (nomfic)
    except os.error as err :
      message  = "fichier " + nomfic
      message += "\nProbleme au remove, erreur numero ", err[0], ":", err[1]
      erreur = 5
#
  else :
#
    erreur = -1
#
  return erreur, message
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def tue_rep (nomrep) :
#
  """
  supprime un repertoire apres avoir fait le menage interne
  code de retour : 0 : Tout va bien
                   1 : Ce n'est pas un repertoire
                   2 : Impossible d'y aller
                   3 : Impossible de faire la liste des fichiers
                   4 : Impossible de supprimer un lien sur un fichier ou un repertoire
                   5 : Impossible de changer les droits sur un fichier
                   6 : Impossible de detruire un fichier
                  10 : Impossible de detruire un repertoire
  """
###  print "\nArguments a l'entree de", __name__, ":", nomrep
#
# 1. Menage du contenu du repertoire
#
  erreur = menage_rep(nomrep)
###    print nomrep , ", erreur = ", erreur
###    print os.system ("ls -la "+nomrep)
#
# 2. Suppression du repertoire lui-meme
#
  if not erreur :
    err = [0]
    try :
      os.rmdir (nomrep)
    except os.error as err :
      print ("Probleme au rmdir, erreur numero ", err[0], ":", err[1])
      erreur = 10
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def menage_rep (nomrep, les_fichiers = "*") :
#
  """
  fait le menage d'un repertoire : destruction des fichiers et des repertoires qu'il contient
   Arguments obligatoire :
     1. Repertoire a examiner
   Arguments optionnel :
     1. Le nom ou la liste du ou des fichiers a supprimer.
        Par defaut, on supprime tout

  code de retour : 0 : Tout va bien
                   1 : Ce n'est pas un repertoire
                   2 : Impossible d'y aller
                   3 : Impossible de faire la liste des fichiers
                   4 : Impossible de supprimer un lien sur un fichier ou un repertoire
                   5 : Impossible de changer les droits sur un fichier
                   6 : Impossible de detruire un fichier
  """
  #print "\nArguments a l'entree de", __name__+"/menage_rep :", nomrep, les_fichiers
#
  erreur = 0
#
  while not erreur :
#
# 1. C'est un repertoire
#
    if os.path.isdir(nomrep) :
#
# 1.1. Passage dans le repertoire
#
      err = [0]
      try :
        os.chmod  (nomrep, 0o755)
      except os.error as err :
        print ("Probleme au chmod, erreur numero ", err[0], ":", err[1])
        erreur = 1
        break
#
# 1.2. Liste des fichiers/repertoires contenus dans le repertoire
#
      l_aux = [ ]
      err = [0]
      try :
        l_aux = os.listdir(nomrep)
      except os.error as err :
        print ("Probleme au listdir, erreur numero ", err[0], ":", err[1])
        erreur = 3
        break
      #print "\n... l_aux = ", l_aux
#
# 1.3. Filtrage de la liste
#
      if ( les_fichiers == "*" ) :
        liste = l_aux
      else :
        if type(les_fichiers) == type("a") :
          lbis = [(les_fichiers, len(les_fichiers)-1)]
        else :
          lbis = [ ]
          for fic in les_fichiers :
            lbis.append((fic, len(fic)-1))
        #print ".. lbis =", lbis
        liste = [ ]
        for cas in lbis :
          fic_supp = cas[0]
          iaux = cas[1]
          #print fic_supp, iaux
          if ( fic_supp[0] == "*" ) :
            for nomfic in l_aux :
              if ( nomfic[-iaux:] == fic_supp[-iaux:] ) :
                liste.append(nomfic)
          elif ( fic_supp[-1] == "*" ) :
            for nomfic in l_aux :
              if ( nomfic[:iaux] == fic_supp[:iaux:] ) :
                liste.append(nomfic)
          else :
            erreur = 1793
            break
        for nomfic in l_aux :
          fic_total = os.path.join(nomrep, nomfic)
          if os.path.isdir(fic_total) :
            erreur = menage_rep(fic_total, les_fichiers = les_fichiers)
            if erreur :
              break
      #print "... liste = ", liste
      if erreur :
        break
#
# 1.4. Menage des fichiers/repertoires contenus dans le repertoire
#
      for nomfic in liste :
#
        fic_total = os.path.join(nomrep, nomfic)
###      print "\n... Fichier ", nomfic, " : ", fic_total
#
        if os.path.islink (fic_total) :
###        print "... passage par le os.path.islink pour ", nomfic, " : ", fic_total
          err = [0]
          try :
            os.unlink (fic_total)
          except os.error as err :
            print ("Probleme au unlink, erreur numero ", err[0], ":", err[1])
            erreur = 4
            break
#
        elif os.path.isdir(fic_total) :
###        print "... passage par le os.path.isdir pour ", nomfic, " : ", fic_total
          if ( les_fichiers == "*" ) :
            erreur = tue_rep(fic_total)
          else :
            erreur = menage_rep(fic_total)
          if erreur :
            break
#
        else :
###        print "... passage par le else pour ", nomfic, " : ", fic_total
          err = [0]
          try :
            os.chmod  (fic_total, 0o755)
          except os.error as err :
            print ("Probleme au chmod, erreur numero ", err[0], ":", err[1])
            erreur = 5
            break
          err = [0]
          try :
            os.remove (fic_total)
          except os.error as err :
            print ("Probleme au remove, erreur numero ", err[0], ":", err[1])
            erreur = 6
            break
#
        if erreur :
          break
#
# 2. Ce n'est pas un repertoire ?
#
    else :
#
      print (nomrep, "n'est pas un repertoire.")
      erreur = 1
      break
#
    break
#
  #print "\nA la sortie de", __name__+"/menage_rep, erreur =", erreur
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def lien (fic_depart = "d", fic_arrivee = "d", destruction = "non") :
#
  """
  On veut  fic_arrivee --> fic_depart
  c'est a dire la commande UNIX : ln -s $fic_depart $fic_arrivee

  Arguments obligatoire :
    1. Fichier depart du lien : c'est le "vrai" fichier
    2. Fichier arrivee du lien : c'est le lien
  Arguments optionnel :
    3. D pour detruire le fichier de depart. Par defaut, on n'y touche pas

  """
#  print "Arguments a l'entree de", __name__, ":", fic_depart, fic_arrivee, destruction
#
#  code de retour :
  messages_erreur = { 0 : "Tout va bien",
                      1 : "Suppression de lien impossible.",
                      2 : "Destruction de fichier impossible.",
                      3 : "Impossible de creer le lien symbolique." }
#
  erreur = 0
#
  while erreur == 0 :
#
    erreur_partiel = [0]
#
# 1. Destruction du fichier d'arrivee
#
# 1.1. C'est un lien
#
    if os.path.islink(fic_arrivee) :
      try :
        os.unlink(fic_arrivee)
      except os.error as erreur_partiel :
        print ("Probleme a la suppression du lien sur le fichier d'arrivee", fic_arrivee)
        print ("Code d'erreur de unlink : ", erreur_partiel[0], ":", erreur_partiel[1])
        erreur = 1
        break
#
# 1.2. C'est un vrai fichier
#
    if os.path.isfile(fic_arrivee) :
      try :
        os.remove(fic_arrivee)
      except os.error as erreur_partiel :
        print ("Probleme a la destruction du fichier d'arrivee", fic_arrivee)
        print ("Code d'erreur de remove : ", erreur_partiel[0], ":", erreur_partiel[1])
        erreur = 2
        break
#
# 2. Destruction eventuelle du fichier de depart
#
    if destruction != "non" :
      if os.path.isfile(fic_depart) :
        try :
          os.remove(fic_depart)
        except os.error as erreur_partiel :
          print ("Probleme a la destruction du fichier de depart", fic_depart)
          print ("Code d'erreur de remove : ", erreur_partiel[0], ":", erreur_partiel[1])
          erreur = 2
          break
#
# 3. On peut faire le lien
#
    try :
      os.symlink(fic_depart, fic_arrivee)
    except os.error as erreur_partiel :
      print ("Probleme au lien entre", fic_depart, "et", fic_arrivee)
      print ("Code d'erreur de symlink : ", erreur_partiel[0], ":", erreur_partiel[1])
      erreur = 3
      break
#
    break
#
# 4. La fin
#
  if erreur :
    print (messages_erreur[erreur])
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def exec_commande (arguments, silence=False) :
#
  """
  Arguments :
    1. Nom de la commande a executer
    2. silence=False(defaut)/True pour afficher les messages d'erreur

  Au retour on a 0 ou !=0 selon que cela a marche ou non
  """
#
  #print "Arguments a l'entree de", __name__, ":", arguments
#
# 1. Execution
#
  commande = arguments[0:]
  #print "commande  =",commande
  erreur = os.system (commande)
  #print "-> erreur =",erreur
#
# 2. La fin
#
  message = ""
  if ( erreur and ( not silence ) ) :
    message += "\nDans le repertoire : " + os.getcwd() + "\n"
    message += "Erreur a l'execution de : " + commande + "\n"
    message += "Code de retour : %d\n" % erreur
    err = [0]
    try :
      message +=  os.strerror(erreur) + "\n"
    except os.error as err :
      message += "Probleme a la sortie du code d'erreur, erreur numero %d" % err[0]
      message += ":" % err[1] + "\n"
    print (message)
#
  return erreur, message
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def verif (texte, reference, calcul) :
#
  """
  Arguments :
    1. Texte a afficher
    2. Resultat de reference
    3. Resultat a comparer
  """
#
  print (texte, ":",)
  if reference == calcul :
    print ("OK\n")
  else :
    print ("echec")
    type_objet = type(calcul)
#    print type_objet
    dico = { }
    type_dictionnaire = type(dico)
    if type_objet == type_dictionnaire :
      for cle in reference.keys() :
        if not calcul.has_key(cle) :
          print (cle, "est present dans la reference, mais pas dans le calcul.")
        else :
          dico[cle] = 1
          if reference[cle] != calcul[cle] :
            print ("Pour ", cle, " : Reference = ", reference[cle])
            print ("Pour ", cle, " : Calcul    = ", calcul[cle])
      for cle in calcul.keys() :
        if not reference.has_key(cle) :
          print (cle, "est present dans le calcul, mais pas dans la reference.")
    else :
      print ("Reference :", reference)
      print ("Calcul    :", calcul, "\n")
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def int_to_str2 (entier) :
#
  """
  transforme un entier positif en une chaine d'au moins deux caracteres
  """
#
#  print "\nArguments a l'entree de", __name__, ":", entier
#
  if type(entier) == type(0) :
    la_chaine = '%02d' % entier
  else :
    la_chaine = None
#
  return la_chaine
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def transfert_repd_repa (rep_depart, rep_arrivee, les_fichiers = "*", verbose = 0 ) :
#
  """
  Transfere le contenu du repertoire rep_depart vers le repertoire rep_arrivee
  Ne transfere pas les fichiers caches en .*, ni les *~ ou *pyc

   Arguments obligatoire :
     1. Repertoire de depart du lien
     2. Repertoire d'arrivee du lien
   Arguments optionnel :
     3. Le nom ou la liste du ou des fichiers a transferer.
        Par defaut, on transfere tout le contenu du repertoire de depart
     4. Niveau des messages : 0, 1, >1

  code de retour : 0 : Tout va bien
                   1 : Ce n'est pas un repertoire.
                   3 : Probleme a la constitution de l'archive.
                   4 : Probleme a l'extraction de l'archive.
                   5 : Impossible de supprimer le fichier d'archive.
                   6 : Impossible de retourner dans le repertoire initial.
  """
  #print "\nArguments a l'entree de", __name__, "/transfert_repd_repa :"
  #print ". rep_depart  :", rep_depart
  #print ". rep_arrivee :", rep_arrivee
#
  erreur = 0
  erreur_partiel = [0]
#
  messages_erreur = { 0 : "Tout va bien",
                      1 : "Ce n'est pas un repertoire.",
                      3 : "Probleme a la constitution de l'archive.",
                      4 : "Probleme a l'extraction de l'archive.",
                      5 : "Impossible de supprimer le fichier d'archive.",
                      6 : "Impossible de retourner dans le repertoire initial." }
#
  repcou = os.getcwd()
#
  while erreur == 0 :
#
# 1. Controle des repertoires
#
    for nomrep in [ rep_depart, rep_arrivee ] :
#
      if not os.path.isdir(nomrep) :
        erreur = 1
        print ("Repertoire", nomrep, ":")
#
    if erreur :
      break
#
# 2. ==> Transfert
# 2.1. ==> Archivage
#
    if verbose :
      print ("....... Archivage depuis", rep_depart)
#
    erreur, message, message_info, fic_tar = archivage (rep_depart, les_fichiers, fic_tar = None, verbose = verbose)
    if erreur :
      print (message_info)
      erreur = 3
      messages_erreur[erreur] += message
      break
#
# 2.2. ==> Extraction dans le repertoire d'arrivee
#
    if verbose :
      print ("....... Extraction dans", rep_arrivee)
#
    erreur, message, message_info = extraction (fic_tar, rep_arrivee, existe_rep=0, verbose = verbose)
    if erreur :
      print (message_info)
      erreur = 4
      messages_erreur[erreur] += message
      break
#
# 2.3. ==> Menage du fichier d'archive
#
    try :
      os.remove (fic_tar)
    except os.error as erreur_partiel :
      print ("Fichier d'archivage", fic_tar)
      print ("Probleme au remove, erreur numero ", erreur_partiel[0], ":", erreur_partiel[1])
      erreur = 5
      break
#
# 3. ==> Retour dans le repertoire courant
#
    try :
      os.chdir(repcou)
    except os.error as erreur_partiel :
      print ("Repertoire initial", repcou)
      print ("Au changement de repertoire, erreur numero" + str(erreur_partiel[0]) + " : " + str(erreur_partiel[1]))
      erreur = 6
      break
#
# 6. La fin
#
    break
#
  if erreur :
    print (messages_erreur[erreur])
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def archivage (rep, les_fichiers = "*", fic_tar = None, verbose = 0) :
#
  """
Archivage des fichiers du repertoire rep
Ne transfere pas les fichiers caches en .*

  Arguments obligatoire :
    1. Repertoire a examiner
  Arguments optionnel :
    2. Le nom ou la liste du ou des fichiers a transferer.
      Par defaut, on transfere tout le contenu du repertoire de depart
    3. Le nom du fichier d'archive.
      Par defaut, un fichier temporaire est cree
    4. Niveau des messages : 0, 1, >1

Retour :
  fic_ar : le fichier d'archive
  erreur : code d'erreur
  """
#
# 1. Prealables
#
  nom_fonction = __name__ + "/archivage"
  blabla = "\nDans " + nom_fonction + " :"
#
  message_info = ""
  messages_erreur = { 0 : None,
                      1 : "Le repertoire est inconnu.",
                      3 : "Probleme a la constitution de l'archive." }
  if ( verbose > 2 ) :
    messages_erreur[0] = "Tout va bien"
    print (blabla)
#
  rep_courant = os.getcwd()
#
  erreur = 0
  erreur_partiel = [0]
#
  while not erreur :
#
# 2. Controles
# 2.1. Existence du repertoire
#
    if not os.path.isdir(rep) :
      erreur = 1
      message_info = "Repertoire " + rep
      break
#
# 2.2. On va dans le repertoire
#
    try :
      os.chdir(rep)
    except os.error as erreur_partiel :
      print ("Repertoire", rep)
      print ("Au changement de repertoire, erreur numero" + str(erreur_partiel[0]) + " : " + str(erreur_partiel[1]))
      erreur = 2
      break
#
# 2.3. Quels fichiers ?
#
    if les_fichiers == "*" :
      saux = les_fichiers
    else :
      if type(les_fichiers) == type("a") :
        saux = les_fichiers
      else :
        saux = " "
        for fic in les_fichiers :
          saux = saux + " " + fic
    if ( verbose > 1 ) :
      message_info += "Fichiers a archiver : " + saux
#
# 3. Archivage
#
    option_ar = "cf"
    if ( verbose > 1 ) :
      option_ar += "v"
#
    if ( fic_tar == None ) :
      t_aux = tempfile.mkstemp()
      fic_tar = t_aux[1]
#
    commande = "tar " + option_ar + " " + fic_tar + " " + saux + " --exclude-vcs --exclude-backups --exclude-caches-all"
    erreur, message = exec_commande (commande)
    if erreur :
      if ( verbose > 0 ) :
        print (message)
      erreur = 3
      break
#
    if ( verbose > 0 ) :
      message_info += "Archivage dans " + fic_tar + "\n"
#
    break
#
# 4. La fin
#
  os.chdir(rep_courant)
#
  if erreur :
    print (blabla, messages_erreur[erreur])
#
  return erreur, messages_erreur[erreur], message_info, fic_tar
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def extraction (fic_tar, rep, existe_rep=0, verbose = 0) :
#
  """
Extraction des fichiers dans un repertoire rep
Supprime les fichiers en *~ ou *pyc

  Arguments obligatoire :
    1. Le nom du fichier d'archive.
    2. Le repertoire d'arrivee
  Arguments optionnel :
    1. Que faire avec le repertoire ?
        0 : le repertoire doit exister (defaut)
        1 : si le repertoire n'existe pas, on le cree
    2. Niveau des messages : 0, 1, >1

Retour :
  erreur : code d'erreur
  """
#
# 1. Prealables
#
  nom_fonction = __name__ + "/extraction"
  blabla = "\nDans " + nom_fonction + " :"
#
  message_info = ""
  messages_erreur = { 0 : None,
                      1 : "Le repertoire est inconnu.",
                      2 : "Impossible de creer le repertoire.",
                      3 : "Probleme a l'extraction de l'archive.",
                      4 : "Erreur au menage." }
  if ( verbose > 2 ) :
    messages_erreur[0] = "Tout va bien"
    print (blabla)
#
  rep_courant = os.getcwd()
#
  erreur = 0
  erreur_partiel = [0]
#
  while not erreur :
#
# 2. Controles
# 2.1. Existence du repertoire
#
    if ( not os.path.isdir(rep) ) :
#
      if ( existe_rep == 0 ) :
        erreur = 1
        message_info = "Repertoire " + rep
        break
      else :
        try :
          os.mkdir(rep)
        except os.error as erreur_partiel :
          print ("Repertoire", rep)
          print ("Creation du repertoire, erreur numero" + str(erreur_partiel[0]) + " : " + str(erreur_partiel[1]))
          erreur = 2
          break
#
# 2.2. On va dans le repertoire
#
    try :
      os.chdir(rep)
    except os.error as erreur_partiel :
      print ("Repertoire", rep)
      print ("Au changement de repertoire, erreur numero" + str(erreur_partiel[0]) + " : " + str(erreur_partiel[1]))
      erreur = 2
      break
#
# 3. Extraction
#
    if ( verbose > 1 ) :
      message_info += "Extraction depuis " + fic_tar + "\n"
#
    option_ar = "xf"
    if ( verbose > 1 ) :
      option_ar += "v"
#
    commande = "tar " + option_ar + " " + fic_tar
    erreur, message = exec_commande (commande)
    if erreur :
      if ( verbose > 1 ) :
        print (message)
      erreur = 3
      break
#
# 4. Menage
#
    erreur = menage_rep (rep, les_fichiers = ["*yc", "*~"])
    if erreur :
      erreur = 4
      break
#
    break
#
# 5. La fin
#
  os.chdir(rep_courant)
#
  if erreur :
    print (blabla, messages_erreur[erreur])
#
  return erreur, messages_erreur[erreur], message_info
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def nettoyage (verbose) :
#
  """
  Nettoie les fichiers lies a un passage de test HOMARD dans le repertoire courant
  """
#
#  print ("\nEntree de", __name__")
#
  erreur = 0
#
  liste_pref = []
#
  liste_brute = [ "core", "Information.donn" ]
  liste_aux = [ "HOMARD", "Adaptation", "Interf_Ap_Ad", "Interf_Av_Ad", "Information" ]
  for pref in liste_aux :
    liste_brute.append(pref+".Configuration")
#
  liste_fic = os.listdir(os.curdir)
  if verbose :
    print (".. Nettoyage de", os.curdir)
#
  for fic in liste_fic :
#  C'est un fichier
    if os.path.isfile(fic) :
#
      a_tuer = 0
#
#     Le fichier est directement a supprimer
      if fic in liste_brute :
        a_tuer = 1
#     Le fichier est une sauvegarde Kate
      elif fic[-1:] == "~" :
        a_tuer = 1
#     Le fichier est une sauvegarde xfig
      elif fic[-3:] == "bak" :
        a_tuer = 1
      else :
#     Le prefixe du fichier est dans la liste
        for pref in liste_pref :
          if fic[:len(pref)] == pref :
            a_tuer = 1
#       Le nom du fichier comporte un .
        if '.' in fic :
#         On decompose selon le(s) point(s)
          laux = fic.split('.')
          lgaux = len(laux)
          #print fic, laux, lgaux
#
          if laux[0] in [ "maill", "indic", "Liste"] :
            a_tuer = 1
          elif lgaux == 2 :
            if laux[0] in [ "info", "front"] :
              a_tuer = 1
          elif lgaux == 3 :
            if laux[0] == "info" and laux[2] == "dat" :
              a_tuer = 1
            elif laux[0] == "info_apres" and laux[2] == "dat" :
              a_tuer = 1
            elif laux[0] == "info_avant" and laux[2] == "dat" :
              a_tuer = 1
            elif laux[0] == "donn" and laux[2] == "info" :
              a_tuer = 1
            elif laux[0] == "donn" and laux[2] == "info_avant" :
              a_tuer = 1
            elif laux[0] == "donn" and laux[2] == "info_apres" :
              a_tuer = 1
            elif laux[0] == "info" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "info_av" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "info_ap" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "avad" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "adap" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "apad" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "modi" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_homa" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_adap" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_avad" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_info" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_modi" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_info_av" and laux[2] == "bilan" :
              a_tuer = 1
            elif laux[0] == "verif_info_ap" and laux[2] == "bilan" :
              a_tuer = 1
          elif lgaux == 4 :
            if laux[3] == "ps" :
              a_tuer = 1
            elif laux[3] == "eps" :
              a_tuer = 1
            elif laux[3] == "fig" :
              a_tuer = 1
            elif laux[0] == "diam" and laux[3] == "dat" :
              a_tuer = 1
            elif laux[0] == "info" and laux[3] == "data" :
              a_tuer = 1
            elif laux[0] == "indic" and laux[3] == "dat" :
              a_tuer = 1
            elif laux[0] == "indic" and laux[3] == "hist" :
              a_tuer = 1
            elif laux[0] == "qual" and laux[3] == "dat" :
              a_tuer = 1
            elif laux[0] == "HOMARD" and laux[1] == "Configuration" and laux[3] == "info" :
              a_tuer = 1
            elif laux[0] == "HOMARD" and laux[1] == "Configuration" and laux[3] == "info_avant" :
              a_tuer = 1
            elif laux[0] == "HOMARD" and laux[1] == "Configuration" and laux[3] == "info_apres" :
              a_tuer = 1
            elif laux[0] == "Information" and laux[1] == "Configuration" and laux[3] == "info" :
              a_tuer = 1
            elif laux[0] == "Information" and laux[1] == "Configuration" and laux[3] == "info_avant" :
              a_tuer = 1
            elif laux[0] == "Information" and laux[1] == "Configuration" and laux[3] == "info_apres" :
              a_tuer = 1
            elif laux[0] == "Interf_Av_Ad" and laux[1] == "Configuration" and laux[3] == "avad" :
              a_tuer = 1
            elif laux[0] == "Interf_Ap_Ad" and laux[1] == "Configuration" and laux[3] == "apad" :
              a_tuer = 1
          elif lgaux == 5 :
            if laux[0] == "HOMARD" and laux[1] == "Configuration" and laux[3] == "vers" :
              a_tuer = 1
            elif laux[0] == "Adaptation" and laux[1] == "Configuration" and laux[3] == "vers" :
              a_tuer = 1
#
#   On supprime ?
      if a_tuer :
        err = [0]
        try :
          os.remove(fic)
        except os.error as err :
          print ("Fichier : ", fic, "Probleme au remove : ", err[0], ":", err[1])
          erreur = 1
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def cree_rep_trav (environnement) :
#
  """
 cree un repertoire de travail
   Argument obligatoire :
     1. Dictionnaire de l'environnement a enrichir

     On y mettra le nom du repertoire de travail cree
  print ("Arguments a l'entree de", __name__, ":", environnement)
  """
#
# 1. Creation du repertoire
#
  rep_trav = tempfile.mkdtemp()
#  print "Creation du repertoire", rep_trav
#
  environnement ["rep_trav"] = rep_trav
#
  return environnement
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def lit_rep ( creation, message_question, verbose ) :
#
  """
 Lit le nom d'un repertoire
 Creation eventuelle
  Retour : le nom complet du repertoire
  """
#
  message = {}
  message["Ligne"] = "\n===============================================================\n"
  message["Repertoire_Nom"]        = "Nom du repertoire : "
  message["Repertoire_Absent"]     = "Ce repertoire n'existe pas."
  message["Repertoire_Creation"]   = "Voulez-vous le creer ? (o/n) \n"
  message["Repertoire_mkdir"]      = "A la creation de ce repertoire"
  message["Erreur_Numero"]         = ", erreur numero "
#
  print (message["Ligne"])
#
  encore = 1
  while encore :
#
    rep = raw_input(message_question)
#
    if len(rep) > 0 :
      if verbose :
        print (rep)
#
      aux = rep.lstrip()
      rep = aux.rstrip()
#
# 1. ==> Le repertoire existe : tout va bien
#
      if os.path.isdir(rep) :
        encore = 0
      else :
#
# 2. ==> Le repertoire n'existe pas
# 2.1. ==> Messages
#
        print (message["Repertoire_Nom"], rep)
        print (message["Repertoire_Absent"])
#
# 2.2. ==> Creation sous condition
#
        if creation :
          var = raw_input(message["Repertoire_Creation"])
          if ( var == "o" or var == "y" ) :
            err = [0]
            try :
              os.mkdir(rep)
            except os.error as err :
              print (message["Repertoire_mkdir"], message["Erreur_Numero"], err[0], ":", err[1])
            if not err[0] :
              encore = 0
#
# 3. ==> Etablissement du nom complet, propre
#
  rep_bis = os.path.join(os.getcwd(), rep)
  if os.path.isdir(rep_bis) :
    rep = rep_bis
  rep = os.path.normpath(rep)
#
  print (message["Ligne"])
#
  return rep
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def creation_executable_version (version_new, version_fic, verbose, verbose_max=0) :
#
  """
  Modifie le numero de version.

  Arguments :
    version_new : le texte de la version a inserer
    version_fic : le fichier a modifier

  Retour :
    erreur :  code d'erreur
  """
#
# 1. Prealables
#
  nom_fonction = __name__ + "/creation_executable_version"
  blabla = "\nDans " + nom_fonction + " :"
  #print blabla
#
  messages_erreur = { 0 : None,
                      1 : "Probleme." }
  if verbose_max :
    messages_erreur[0] = "Tout va bien"
#
#
  erreur = 0
  print (". Passage a la version ", version_new)
  if verbose :
    print (". version_fic :", version_fic)
#
# 2. Lecture du fichier
#
  fic = open (version_fic, "r")
  les_lignes = fic.readlines()
  fic.close()
#
# 3. Ecriture modifiee du fichier
#
  fic = open (version_fic, "w")
  for ligne in les_lignes :
    ligne_bis = ligne
    if "parameter" in ligne :
      ligne_bis = "      parameter ( nuvers = '" + version_new + "' )\n"
    fic.write(ligne_bis)
    if verbose_max :
      print (ligne_bis[:-1])
  fic.close()
#
  os.chmod (version_fic, 0o644)
#
  if erreur :
    print (blabla, messages_erreur[erreur])
#
  return erreur
#
#=========================  Fin de la fonction  ===================================
#
#========================= Debut de la fonction ===================================
#
def creation_makefile_tests (d_option, verbose=0, verbose_max=0) :
#
  """
Creation du makefile pour les cas-tests

Arguments obligatoires :

Retour :
erreur :  code d'erreur
  """
#
# 1. Prealables
#
  nom_fonction = __name__ + "/creation_makefile_tests"
  blabla = "\nDans " + nom_fonction + " :"
#
  messages_erreur = { 0 : None,
                      1 : "Le fichier Makefile.am est inconnu." }
  if verbose_max :
    print (blabla)
    messages_erreur[0] = "Tout va bien"
#
  erreur = 0
#
  while not erreur :
#
    l_option = d_option.keys()
#
# 2. Creation du makefile pour la creation des cas-tests
#
    rep = os.path.join(d_option["REP_TESTS"], "Util")
#
# 2.1. Lecture de la base
#
    nomfic = os.path.join(rep, "Makefile.am")
    if ( os.path.isfile(nomfic) ) :
      fichier = open (nomfic, "r")
      les_lignes = fichier.readlines()
      fichier.close()
    else :
      erreur = 1
      break
#
# 2.2. Ecriture
#
    nomfic = os.path.join(rep, "Makefile")
    fichier = open (nomfic, "w")
#
# 2.2.1. Particularites
#
    ligne = ""
    for cle in l_option :
      ligne += cle + " = " + d_option[cle] + "\n"
#
    fichier.write(ligne)
#
# 2.2.2. La base
#
    for ligne in les_lignes :
      fichier.write(ligne)
#
    fichier.close()
#
# 2.3. Menage des objets
#
    fichier = os.path.join(rep, "uttfi2.o")
    if os.path.isfile(fichier) :
      os.remove(fichier)
#
    break
#
# 3. La fin
#
  if erreur and verbose_max :
    print (blabla, messages_erreur[erreur])
#
  return erreur, messages_erreur[erreur]
#
#=========================  Fin de la fonction  ===================================
#
#=========================       Auto-test      ===================================
#
if __name__ == '__main__' :
#
  PREFIX = "HOMARD_AUTO_TEST_"
  REP_TRAV_BASE = tempfile.gettempdir()
  print ("REP_TRAV_BASE =", REP_TRAV_BASE)
#
  NOMTEMP = "/tagada/tsoin/tsoin"
  print (tue_rep(NOMTEMP))
#
  NOMTEMP = tempfile.mkdtemp()
  print ("\nCreation du repertoire", NOMTEMP)
  print (tue_rep(NOMTEMP))
  print ("\nDestruction du repertoire", NOMTEMP)
#
  NOMFIC_D = os.path.join(REP_TRAV_BASE, "toto")
  NOMFIC_A = os.path.join(REP_TRAV_BASE, PREFIX+"tutu")
  print (lien (NOMFIC_D, NOMFIC_A))
#
  print (lien (NOMFIC_D, NOMFIC_A, "oui"))
#
  L1 = "ls -ltr $HOME"
  L1_REFE = 0
  L1_CALC = exec_commande(L1)
  verif ("Test sur exec_commande avec "+L1, L1_REFE, L1_CALC)
#
  D3 = { }
  D3_REFE = {'REP_TRAV': REP_TRAV_BASE }
  D3_CALC = cree_rep_trav(D3)
  verif ("Test sur cree_rep_trav" , D3_REFE, D3_CALC)
  #print "REP_TRAV =", D3_CALC["REP_TRAV"]
  print (tue_rep(D3_CALC["REP_TRAV"]))
#
  print (transfert_repd_repa ("/tmps", REP_TRAV_BASE))
  print (transfert_repd_repa (REP_TRAV_BASE, "/tmpu"))
  NOMTEMP = tempfile.mkdtemp()
  print (transfert_repd_repa ("/scratch/D68518/HOMARD_SVN/trunk/tools", NOMTEMP))
  print (tue_rep(NOMTEMP))
#
  os.system("touch "+os.path.join(REP_TRAV_BASE, PREFIX+"glop"))
  NOMTEMP = tempfile.mkdtemp()
  print ("\nCreation du repertoire", NOMTEMP)
  ERREUR = transfert_repd_repa (REP_TRAV_BASE, NOMTEMP, PREFIX+"glop")
#
  L_AUX = ["ga", "bu", "zo" , "me"]
  L_AUX_1 = []
  for FIC_MAIN in L_AUX :
    NOMFIC = PREFIX + FIC_MAIN
    os.system("touch "+os.path.join(REP_TRAV_BASE, NOMFIC))
    L_AUX_1.append(NOMFIC)
  ERREUR = transfert_repd_repa (REP_TRAV_BASE, NOMTEMP, L_AUX_1, 1)
  print (tue_rep(NOMTEMP))

