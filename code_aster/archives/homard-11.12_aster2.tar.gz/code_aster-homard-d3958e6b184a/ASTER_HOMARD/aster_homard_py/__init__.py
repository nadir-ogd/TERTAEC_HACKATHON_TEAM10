# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V2.1"
