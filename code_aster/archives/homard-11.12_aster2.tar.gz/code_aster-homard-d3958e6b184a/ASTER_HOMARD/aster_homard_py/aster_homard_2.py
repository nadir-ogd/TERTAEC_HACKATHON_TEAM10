# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
Recuperation des options dans le fichier de configuration

"""
__revision__ = "V2.12"
#
import os
#
#========================= Debut de la fonction ==================================
#
def aster_homard_2 (dict_arguments, fic_conf, message_info="") :
#
  """
But :
  Recuperation des options dans le fichier de configuration

Arguments :
  1. Environnement : nom du fichier de configuration et nom du fichier de donnees
  2. nom du fichier de configuration
  3. message_info : les messages d'information a completer
  """
#
# 1. code de retour :
  blabla = "\nDans " + __name__ + " : "
  messages_erreur = { 0 : "",
                      1 : "Le fichier de configuration pour HOMARD est inconnu." }
#
#  print (blabla, "\nfic_conf :", fic_conf)
  variables_conf = {}
  verbose = dict_arguments["verbose"]
#
# 2. Verification
#
  if not os.path.isfile(fic_conf) :
    code_erreur = 1
  else :
    code_erreur = 0
#
  if not code_erreur :
#
# 2. Lecture du fichier
#    Chaque ligne est convertie en une liste 'ligne', puis stockee dans une liste 'les_lignes'
#    On supprime les lignes vides et les lignes de commentaires
#
    if ( verbose ) :
      message_info += "\n.. Fichier de configuration pour HOMARD"
#
    with open(fic_conf, "r") as fichier :
      tout = fichier.readlines()
    #print ("tout :", tout)
    #print ("fichier : %s" % fic_conf)
#
    les_lignes = []
    for ligne in tout :
      if ( len(ligne) > 1 ) :
        if ( ligne[0] != "#" ) :
          les_mots = ligne.split()
          les_lignes.append(les_mots)
          if ( verbose ) :
            message_info += "\n" + ligne[:-1]
    if ( verbose ) :
      message_info += "\n"
#
# 3. Recherche des infos necessaires
# 3.1. Le mode d'utilisation de HOMARD
#
    mot_cle = "ModeHOMA"
    for indice in range(len(les_lignes)) :
##      print (les_lignes[indice][0:])
      if les_lignes[indice][0] == mot_cle :
        variables_conf [mot_cle] = int(les_lignes[indice][1])
        break
    modehoma = variables_conf [mot_cle]
#
# 3.2. Les autres options et informations liees aux fichiers
#
    mots_cles_option = [ "ListeStd", "NumeIter", "PPBasFic" ]
    mots_cles_fic = { "CCMaiN__":2  }
#
    if modehoma == 1 or modehoma == 3 :
      mots_cles_fic ["HOMaiN__"] = 3
      mots_cles_fic ["HOMaiNP1"] = 3
      mots_cles_fic ["CCMaiN__"] = 2
      mots_cles_fic ["CCMaiNP1"] = 2
      mots_cles_option.append("CCNoMNP1")
      mots_cles_option.append("HOMaiNP1")
#
    if modehoma == 1 :
      mots_cles_fic ["CCIndica"] = 2
      mots_cles_fic ["CCSolN__"] = 2
      mots_cles_fic ["CCSolNP1"] = 2
#
    for mot_cle in mots_cles_option :
      for indice in range(len(les_lignes)) :
        if les_lignes[indice][0] == mot_cle :
          variables_conf [mot_cle] = les_lignes[indice][1]
          break
#
    for mot_cle in mots_cles_fic :
      place = mots_cles_fic[mot_cle] - 1
      for indice in range(len(les_lignes)) :
        if les_lignes[indice][0] == mot_cle :
          variables_conf [mot_cle+"_fic"] = les_lignes[indice][place]
          break
#
  if verbose :
    l_aux = list(variables_conf.keys())
    l_aux.sort()
    message_info += ".. variables_conf ="
    for cle in l_aux :
      message_info += "\n  " + cle + " : " + str(variables_conf[cle])
    message_info += "\n"
#
# 4. La fin
#
  variables_conf["code_de_retour"] = code_erreur
#
  if code_erreur :
    saux  =  blabla + "erreur de programmation\n"
    saux += "Fichier " + fic_conf + "\n" + messages_erreur[code_erreur]
  else :
    saux = ""
#
  return code_erreur, message_info, saux, variables_conf
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
  import tempfile
#
  D1 = {'verbose': 0 }
  T_AUX = tempfile.mkstemp()
  F1 = T_AUX[1]
  os.remove(F1)
  M1 = "gabuzome"
  L1_REFE = {'code_de_retour': 1}
  CODE_ERREUR, MESSAGE_INFO, SAUX, L1_CALC = aster_homard_2 (D1, F1, M1)
  verif ("Test sur L1", L1_REFE, L1_CALC)
#
  D2 = {'verbose': 1 }
  T_AUX = tempfile.mkstemp()
  FIC_CONF_TEST = T_AUX[1]
  with open(FIC_CONF_TEST, "w") as FICHIER_TEST :
    SAUX = "ModeHOMA 1\n"
    FICHIER_TEST.write(SAUX)
  M2 = ""
  L2 = FIC_CONF_TEST
  L2_REFE = {'ModeHOMA': 1, 'code_de_retour': 0}
  CODE_ERREUR, MESSAGE_INFO, SAUX, L2_CALC = aster_homard_2 (D2, L2, M2)
  verif ("Test sur L2", L2_REFE, L2_CALC)
  os.remove(FIC_CONF_TEST)
#
