# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V2.11"
#
import os
#
from .aster_homard_utilitaires   import int_to_str2
#
#========================= Debut de la fonction ==================================
#
def aster_homard_4 (environnement, dict_arguments, variables_conf, code_retour_exec, message_info="") :
#
  """
Arguments :
  1. Dictionnaire de l'environnement
  2. Dictionnaire des arguments generaux
  3. Dictionnaire des variables de configuration
  4. Code de retour de l'execution de HOMARD
  5. message_info : les messages d'information a completer
  """
#
# 1. code de retour :
  blabla = "\nDans " + __name__ + " :"
  messages_erreur = { 0 : "" }
  code_erreur = 0
  message_erreur = messages_erreur[0]
#
#  print (blabla, environnement, dict_arguments, variables_conf, code_retour_exec)
  verbose = dict_arguments["verbose"]
  modehoma = variables_conf["ModeHOMA"]
  nivinf = dict_arguments ["nivinf"]
  fic_conf = environnement["fic_conf"]
#
  if verbose :
    print (blabla)
#
# 2. Archivage des fichiers
# 2.1. Prealable
#
  niter = int(variables_conf["NumeIter"])
  aux_niter = int_to_str2(niter)
#
  niterp1 = niter + 1
  aux_niterp1 = int_to_str2(niterp1)
#
###  print ("modehoma =",modehoma)
  if modehoma == 1 :
    action = "avad"
  elif modehoma == 3 :
    action = "modi"
  else :
    action = "info"
#
  if verbose :
    l_aux = os.listdir(os.curdir)
    l_aux.sort()
    message_info += "\n.. Fichiers presents dans le repertoire d'execution de HOMARD :"
    for fic in l_aux :
      message_info += "\n.... " + fic
#
# 2.2. La liste standard :
#          . si le mode est verbeux
#       ou . s'il y a eu un probleme a l'execution
#       ou . si le niveau d'information est > 3
#
  if ( verbose or code_retour_exec != 0 or nivinf > 3 ) :
    ecrire_listestd = 1
    liste = [variables_conf["ListeStd"]]
  else :
    ecrire_listestd = 0
    liste = [ ]
#
# 2.3. Les fichiers de bilan
#
###  print ("2.3. niter  = ", niter)
###  print ("2.3. action = ", action)
  if ( niter == 0 ) :
    liste.append("homa.00.bilan")
    liste.append(action+".00.bilan")
    if verbose :
      liste.append("verif_"+action+".00.bilan")
#
  for saux in ["noeu", "aret", "tria", "tetr", "quad", "hexa", "pyra", "pent"] :
    liste.append("indic."+saux+"."+aux_niter+".hist")
#
  liste.append("apad."+aux_niterp1+".bilan")
  if verbose :
    liste.append("verif_apad."+aux_niterp1+".bilan")
#
# 2.4. Le fichier de configuration
#           . si le niveau d'information est > 3
#        et . s'il y a eu un probleme a l'execution
#
  if ( code_retour_exec != 0 and nivinf > 3 ) :
    liste.append(fic_conf)
#  print (liste)
#
# 2.5. Recuperation des textes
#      Remarque : je ne sais pas mieux faire que de tout lire et d'imprimer ensuite ...
#
  for fic in liste :
    if os.path.isfile (fic) :
      message_info += "\n"
      if verbose :
        message_info += ".... fichier : " + fic + "\n"
      with open(fic, "r") as fichier :
        tout = fichier.read()
#      print (tout)
      message_info += tout
#
# 2.6. Affichage des mesures de temps de calcul, si le fichier complet n'a pas deja ete ecrit
#
  if not ecrire_listestd :
    message = "\n.......................................................................\n"
    fic = variables_conf["ListeStd"]
    if os.path.isfile (fic) :
      with open(fic, "r") as fichier :
        tout = fichier.readlines()
      for ligne in tout :
        chaines = ligne.split()
        jaux = len(chaines)
        if jaux >= 8 :
          if chaines[0] == ":" :
            if chaines[1] in [ "Temps", "Total", "Memoire" ] :
              message = message + ligne
              if chaines[1] in [ "Memoire" ] :
                message = message + ":.....................................................................:\n"
    message = message + ":.....................................................................:\n"
    message_info += message
#
# 2.7. Archivage du fichier de configuration
#      Remarque : il faut copier et non pas renommer car on en a encore besoin
#
  if dict_arguments["PERSO"] == "oui" :
    if modehoma == 1 :
      saux = ".vers."+aux_niterp1
    else :
      saux = ".info"
    with open(fic_conf, "r") as fichier :
      tout = fichier.read()
    fic = fic_conf+"."+aux_niter+saux
    with open(fic, "w") as fichier :
      fichier.write(tout)
#
# 3. S'il y a eu un probleme a l'execution, les messages d'erreur
#
  if ( code_retour_exec ) :
#
# 3.1. ==> Lecture du fichier de sortie standard de HOMARD
#
    with open(variables_conf["ListeStd"], "r") as fichier :
      tout = fichier.readlines()
#
# 3.2. ==> Decodage
#          En attente d'une gestion 'a la Aster' des messages d'erreur, on
#          recupere la fin de la sortie qui contient en general les messages
#          d'erreur.
#
###    for line in tout :
###      print (line[:-1])
#
    saux_1 = "======"
    saux_1_1 = len(saux_1)
    saux_2 = "               ....................................."
    saux_2_1 = len(saux_2)
    l_aux = [ "Probleme : code retour =", "Sortie du sous-programme" ]
    daux = {}
    for saux in l_aux :
      daux[saux] = len(saux)
    line_1 = ""
    erreur_vu = 0
#
    for line in tout :
      imprime = 1
      if len(line) >= saux_1_1 :
        if line[0:saux_1_1] == saux_1 :
          message_erreur = line_1
      if len(line) >= saux_2_1 :
        if ( line[0:saux_2_1] == saux_2 and erreur_vu ) :
          break
      for saux in l_aux :
        if len(line) >= daux[saux] :
          if line[0:daux[saux]] == saux :
            imprime = 0
            erreur_vu = 1
##    print (imprime,line,message_erreur)
      if imprime :
        message_erreur += line
      line_1 = line
#
# 4. La fin
#
  return code_erreur, message_info, message_erreur
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
#
  E1 = { "fic_donn" : "DONN", "fic_conf" : "HOMARD.Configuration" }
  A1 = {"verbose" : 1, 'PERSO': "non", 'nivinf': 2 }
  V1 = {'NumeIter': '3', 'PPBasFic': 'INFO', 'ModeHOMA': 2, 'ListeStd': 'aster_homard_5.py' }
  L1_REFE = [0]
  L1_CALC = aster_homard_4 (E1, A1, V1, 0)
  if L1_CALC[0] :
    print ("L1_CALC =", L1_CALC)
  verif ("Test sur L1", L1_REFE[0], L1_CALC[0])
#
  FIC_CONF_TEST = "HOMARD.Configuration"
  with open(FIC_CONF_TEST, "w") as FICHIER_TEST :
    SAUX = "ModeHOMA 1\n"
    FICHIER_TEST.write(SAUX)
  FIC_LISTE_TEST = "Liste.00.vers.01"
  with open(FIC_LISTE_TEST, "w") as FICHIER_TEST :
    SAUX = "ModeHOMA 1\n"
    FICHIER_TEST.write(SAUX)
  E2 = { "fic_donn" : "DONN", "fic_conf" : FIC_CONF_TEST }
  A2 = {"verbose" : 1, 'PERSO': "oui", 'nivinf': 1 }
  V2 = {'NumeIter': '3', 'PPBasFic': 'INFO', 'ModeHOMA': 2, 'ListeStd': FIC_LISTE_TEST }
  L2_REFE = [0]
  L2_CALC = aster_homard_4 (E2, A2, V2, 8)
  if L2_CALC[0] :
    print ("L2_CALC =", L2_CALC)
  verif ("Test sur L2", L2_REFE[0], L2_CALC[0])
  os.remove(FIC_LISTE_TEST)
  os.remove(FIC_CONF_TEST)
  os.remove(FIC_CONF_TEST+".03.info")
