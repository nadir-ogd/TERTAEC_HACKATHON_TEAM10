# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
Copie des fichiers d'echange pour le deboggage ulterieur
Copie avant ou apres adaptation
"""
__revision__ = "V2.09"
#
import os
import shutil
#
from .aster_homard_utilitaires   import int_to_str2
#
#========================= Debut de la fonction ==================================
#
def aster_homard_6 (environnement, dict_arguments, variables_conf, quand, message_info="") :
#
  """
   Arguments :
     1. Dictionnaire de l'environnement
     2. Dictionnaire des arguments generaux
     3. Dictionnaire des variables de configuration
     4. quand : "av" ou "ap" pour connaitre le moment de la copie
     5. message_info : les messages d'information a completer
  """
#
# 1. code de retour :
  blabla = "\nDans " + __name__ + " :"
  code_erreur = 0
  message_erreur = ""
#
  fic_conf = environnement["fic_conf"]
#
  #print (blabla, "\nenvironnement :", environnement, "\ndict_arguments :", dict_arguments, "\nvariables_conf :", variables_conf)
#
  verbose = dict_arguments["verbose"]
  rep_debug = dict_arguments ["rep_debug"]
###  print ("glop rep_debug = ",rep_debug)
  rep_calc_logiciel = dict_arguments ["rep_calc_LOGICIEL"]
###  print ("glop rep_calc_logiciel =",rep_calc_logiciel)
  modehoma = variables_conf["ModeHOMA"]
#
  niter = int(variables_conf["NumeIter"])
  aux_niter = int_to_str2(niter)
#
  niterp1 = niter + 1
  aux_niterp1 = int_to_str2(niterp1)
#
  ccmain___fic = variables_conf["CCMaiN___fic"]
  ccmain___fic_rep = None
  if len(os.path.dirname(ccmain___fic)) > 0 :
    ccmain___fic_rep = os.path.dirname(ccmain___fic)
#
  ccmainp1_fic = None
  if ( "CCMaiNP1_fic" in variables_conf ) :
    ccmainp1_fic = variables_conf["CCMaiNP1_fic"]
    if len(os.path.dirname(ccmainp1_fic)) > 0 :
      ccmainp1_fic_rep = os.path.dirname(ccmainp1_fic)
#
  ccindica_fic = None
  if ( "CCIndica_fic" in variables_conf ) :
    ccindica_fic = variables_conf["CCIndica_fic"]
    if len(os.path.dirname(ccindica_fic)) > 0 :
      ccindica_fic_rep = os.path.dirname(ccindica_fic)
#
  homain___fic = variables_conf["HOMaiN___fic"]
  homain___fic_rep = None
  if len(os.path.dirname(homain___fic)) > 0 :
    homain___fic_rep = os.path.dirname(homain___fic)
#
  homainp1_fic = None
  if ( "HOMaiNP1_fic" in variables_conf ) :
    homainp1_fic = variables_conf["HOMaiNP1_fic"]
    if len(os.path.dirname(homainp1_fic)) > 0 :
      homainp1_fic_rep = os.path.dirname(homainp1_fic)
#
  executable = dict_arguments["executable"]
#
  if verbose :
    print (blabla)
#
  while not code_erreur :
#
# 2. Donnees pour les informations
# 2.1. Liste des fichiers
#
#gn    print (os.listdir(rep_calc_logiciel))
    if quand == "av" :
      l_aux = [ ccmain___fic ]
      if ( ccindica_fic is not None and ccindica_fic != ccmain___fic ) :
        l_aux.append(ccindica_fic)
      if niter > 0 :
        l_aux.append(homain___fic)
      if modehoma == 2 :
        l_aux.append("HOMARD.Donnees")
    elif quand == "ap" :
      l_aux = [ ccmainp1_fic, homainp1_fic ]
    else :
      l_aux = [ ]
#
# 2.2. Copie effective
#
    for fic in l_aux :
      if os.path.isfile(fic) :
        if ( fic == "HOMARD.Donnees" ) :
          saux = "donn."+aux_niter+".info"
        else :
          saux = os.path.basename(fic)
        fic_2 = os.path.join(rep_debug, saux)
        try :
          shutil.copyfile(fic, fic_2)
        except OSError as err :
          message_erreur  = "Impossible de copier %s dans %s" % (fic, fic_2)
          print(message_erreur, err)
          code_erreur = 31
          break
#
# 2.3. Ajout de donnees bidon pour les futures informations
#
    if modehoma == 1 :
      ligne = "0\n0\nq\n"
      if niter == 0 :
        l_aux = [ "00.info" ]
      else :
        l_aux = [ aux_niter + ".info_avant" ]
      l_aux.append( aux_niterp1 + ".info_apres" )
      for suffixe in l_aux :
        fic = os.path.join(rep_debug, "donn."+suffixe)
        with open(fic, "w") as fichier :
          fichier.write(ligne)
#
# 3. Fichier de configuration
#
    fic = os.path.join(rep_calc_logiciel, fic_conf)
    with open(fic, "r") as fichier :
      les_lignes = fichier.readlines()
    #print ("les_lignes =\n", les_lignes)
#
    les_lignes_bis = []
    if modehoma == 2 :
      saux = "."+aux_niter+".info"
    else :
      saux = "."+aux_niter+".vers."+aux_niterp1
    fic_2 = os.path.join(rep_debug, fic_conf+saux)
    fic = os.path.join(rep_debug, fic_2)
    with open(fic, "w") as fichier :
##      print ("CCMaiN___fic = ", CCMaiN___fic)
##      print ("CCMaiN___fic_rep = ", CCMaiN___fic_rep)
      for ligne in les_lignes :
        ligne_bis = ligne
        aux1 = None
##        print (ligne, ligne.find(CCMaiNP1_fic))
        if ( ligne.find(rep_calc_logiciel) >= 0 ) :
          aux1 = rep_calc_logiciel
          aux2 = "."
        elif ( ligne.find(ccmain___fic) >= 0 ) :
          aux1 = ccmain___fic_rep
          aux2 = rep_debug
        elif ( ccmainp1_fic is not None ) :
          if ( ligne.find(ccmainp1_fic) >= 0 ) :
            aux1 = os.path.join(ccmainp1_fic_rep, ccmainp1_fic)
            aux2 = os.path.join(rep_debug, "maill."+aux_niterp1+".med" )
        elif ( ccindica_fic is not None ) :
          if ( ligne.find(ccindica_fic) >= 0 ) :
            aux1 = ccindica_fic_rep
            aux2 = rep_debug
        elif ( ligne.find(homain___fic) >= 0 ) :
          aux1 = homain___fic_rep
          aux2 = rep_debug
        elif ( homainp1_fic is not None ) :
          if ( ligne.find(homainp1_fic) >= 0 ) :
            aux1 = os.path.join(homainp1_fic_rep, homainp1_fic)
            aux2 = os.path.join(rep_debug, "maill."+aux_niterp1+".med" )
        if ( aux1 is not None ) :
          ligne_bis = ligne.replace(aux1, aux2)
        les_lignes_bis.append(ligne_bis)
        fichier.write(ligne_bis)
    #print ("les_lignes_bis =\n", les_lignes_bis)
#
#   Ajout de fichiers de configuration pour les futures informations
    if modehoma == 1 :
      if niter == 0 :
        l_aux = [ "00.info" ]
      else :
        l_aux = [ aux_niter + ".info_avant" ]
      l_aux.append( aux_niterp1 + ".info_apres" )
      for suffixe in l_aux :
        fic = os.path.join(rep_debug, fic_conf+"."+suffixe)
        with open(fic, "w") as fichier :
          for ligne in les_lignes_bis :
            ligne_bis = ligne
            aux1 = None
            #print (ligne)
            if ( "ModeHOMA" in ligne ) :
              ligne_bis = "ModeHOMA 2\n"
            elif ( "ListeStd" in ligne ) :
              ligne_bis = "ListeStd Liste."+suffixe+"\n"
            if ( suffixe != "00.info" ) :
              if ( "CCAssoci" in ligne ) :
                ligne_bis = "CCAssoci HOMARD\n"
            if ( suffixe == aux_niterp1+".info_apres" ) :
              if ( "HOMaiN__" in ligne ) :
                ligne_bis = "#\n"
              elif ( "HOMaiNP1" in ligne ) :
                ligne_bis = ligne.replace("HOMaiNP1", "HOMaiN__")
            else :
              if ( "HOMaiNP1" in ligne ) :
                ligne_bis = "#\n"
            fichier.write(ligne_bis)
#
# 4. Variables annexes
#
    if "MED_HOME" in os.environ :
      med_home = os.environ ["MED_HOME"]
    else :
      med_home = os.environ ["HOME"]
    mdump = os.path.join(med_home, "bin", "mdump")
#
# 5. Makefile
#
    fic = os.path.join(rep_debug, "Makefile")
    with open(fic, "w") as fichier :
#
# 5.1. En-tete
#
      makefile_t1  = "REP_LOCAL = " + rep_debug + "\n"
      makefile_t1 += "EXEC = " + executable + "\n"
      makefile_t1 += "MDUMP = " + mdump + "\n"
      makefile_t1 += "MODE_DUMP_HO = -nodump_ho\n"
      makefile_t1 += "NOMFIC_DONN_MED_DUMP = $(REP_LOCAL)/donn\n"
      makefile_t1 += "NOMFIC_DONN_HOMMED_DUMP = $(REP_LOCAL)/donnd\n"
      makefile_t1 += "NOMFIC_DONN_HOMMED_DUMP = $(REP_LOCAL)/donn\n"
#
      for ligne in makefile_t1 :
        fichier.write(ligne)
#
# 5.2. Indexation generale
#
      ligne = "#\n"
      ligne += "all :"
      for naux in range(niterp1) :
        auxd = int_to_str2(naux)
        auxf = int_to_str2(naux+1)
        if naux == 0 :
          ligne += " 00.info"
        else :
          ligne += " " + auxd + ".info_avant"
        ligne += " " + auxd + ".vers." + auxf + " " + auxf + ".info_apres"
      ligne += "\n#\n"
      fichier.write(ligne)
#
# 5.3. Chacune des iterations
#
      ligne = "#\n"
#
      for naux in range(niterp1) :
        auxd = int_to_str2(naux)
        auxf = int_to_str2(naux+1)
        if naux == 0 :
          ligne += "00.info :\n"
          ligne += "\t@ /bin/cp $(REP_LOCAL)/" + fic_conf + ".00.info $(REP_LOCAL)/" + fic_conf + "\n"
          ligne += "\ttime $(EXEC) < $(REP_LOCAL)/donn.00.info\n"
        else :
          ligne += auxd + ".info_avant :\n"
          ligne += "\t@ /bin/cp $(REP_LOCAL)/" + fic_conf + "." + auxd + ".info_avant $(REP_LOCAL)/" + fic_conf + "\n"
          ligne += "\ttime $(EXEC) < $(REP_LOCAL)/donn." + auxd + ".info_avant\n"
        ligne += "#\n"
        ligne += auxd + ".vers." + auxf + " :\n"
        ligne += "\t@ /bin/cp $(REP_LOCAL)/" + fic_conf + "." + auxd + ".vers." + auxf + " $(REP_LOCAL)/" + fic_conf + "\n"
        ligne += "\ttime $(EXEC)\n"
        ligne += "\tif test -f $(REP_LOCAL)/maill." + auxf + ".med ; then $(MDUMP) $(REP_LOCAL)/maill." + auxf + ".med > $(REP_LOCAL)/maill." + auxf + ".med.dump < $(NOMFIC_DONN_MED_DUMP) ; fi\n"
        ligne += "\tif test $(MODE_DUMP_HO) = '-dump_ho' ; then if test -f $(REP_LOCAL)/maill." + auxf + ".hom.med ; then $(MDUMP) $(REP_LOCAL)/maill." + auxf + ".hom.med > $(REP_LOCAL)/maill." + auxf + ".hom.med.dump < $(NOMFIC_DONN_HOMMED_DUMP) ; fi ; fi\n"
        if naux == 0 :
          ligne += "\tif test $(MODE_DUMP_HO) = '-dump_ho' ; then if test -f $(REP_LOCAL)/maill.00.hom.med ; then $(MDUMP) $(REP_LOCAL)/maill.00.hom.med > $(REP_LOCAL)/maill.00.hom.med.dump < $(NOMFIC_DONN_HOMMED_DUMP) ; fi ; fi\n"
        ligne += "#\n"
        ligne += auxf + ".info_apres :\n"
        ligne += "\t@ /bin/cp $(REP_LOCAL)/" + fic_conf + "." + auxf + ".info_apres $(REP_LOCAL)/" + fic_conf + "\n"
        ligne += "\ttime $(EXEC) < $(REP_LOCAL)/donn." + auxf + ".info_apres\n"
        ligne += "#\n"
      ligne += "\n#\n"
      fichier.write(ligne)
#
#
#
    break
#
# 6. La fin
#
  return code_erreur, message_info, message_erreur
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
#
  FIC_CONF_TEST = "HOMARD.Configuration"
  with open(FIC_CONF_TEST, "w") as FICHIER_TEST :
    SAUX = "ModeHOMA 1\n"
    FICHIER_TEST.write(SAUX)
#
  E1 = { "fic_donn" : "DONN", "fic_conf" : FIC_CONF_TEST }
  A1 = {"verbose" : 1, "rep_debug" : "/tmp", "rep_calc_LOGICIEL" : os.getcwd(), 'PERSO': "non", 'nivinf': 2, "executable" : "more" }
  V1 = {'NumeIter': '3', 'PPBasFic': 'INFO', 'ModeHOMA': 2, 'ListeStd': 'aster_homard_5.py', "CCMaiN___fic" : "/tmp/tmp", "HOMaiN___fic" : "/tmp/tmpa"  }
  L1_REFE = (0, '', '')
  L1_CALC = aster_homard_6 (E1, A1, V1, 0)
  if L1_CALC[0] :
    print ("L1_CALC =", L1_CALC)
  verif ("Test sur L1", L1_REFE, L1_CALC)
#
  E2 = { "fic_donn" : "DONN", "fic_conf" : FIC_CONF_TEST }
  A2 = {"verbose" : 1, "rep_debug" : "/tmp", "rep_calc_LOGICIEL" : os.getcwd(), 'PERSO': "oui", 'nivinf': 1, "executable" : "more" }
  V2 = {'NumeIter': '3', 'PPBasFic': 'INFO', 'ModeHOMA': 2, 'ListeStd': 'gabuzome', "CCMaiN___fic" : "/tmp/tmp", "HOMaiN___fic" : "/tmp/tmpa" }
  L2_REFE = (0, '', '')
  L2_CALC = aster_homard_6 (E2, A2, V2, 8)
  if L2_CALC[0] :
    print ("L2_CALC =", L2_CALC)
  verif ("Test sur L2", L2_REFE, L2_CALC)
  os.remove(FIC_CONF_TEST)
