# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V3.08"
#
import os
import sys
#
from .aster_homard_1             import aster_homard_1
from .aster_homard_2             import aster_homard_2
from .aster_homard_3             import aster_homard_3
from .aster_homard_4             import aster_homard_4
#from .aster_homard_5             import aster_homard_5
from .aster_homard_6             import aster_homard_6
#
def aster_homard (arguments, message_info) :
#
  """
Arguments :
  1. Repertoire de reference de HOMARD sur la machine
  2. Sous-repertoire dans lequel aura lieu l'execution de homard
  3. Version de HOMARD
  4. Niveau d'information au sens ASTER
  5. Nom du fichier de donnees en mode information, 0 sinon
  N. rien, si version publique de HOMARD
    -PERSO, si version personnelle
  N. rien, si pas de copie pour debogagge
    rep_debug, le repertoire pour y copier les fichiers echanges
  N. rien, si silencieux
    -verbose, sinon
  message_info : les messages d'information a completer

Remarque : ces arguments sont transmis sous forme d'une chaine de caracteres
  """
#
# 1. Initialisation
#
  message_erreur = ""
#
  #blabla = "\nDans " + sys.argv[0] + ", avant appel a aster_homard_"
#
  rep_calc_aster = os.getcwd()
#
#  constantes :
  environnement = { "fic_conf" : "HOMARD.Configuration",
                    "rep_calc_aster" : rep_calc_aster }
#
# 2. Decodage des arguments
#
###  print (blabla, "1, :" + "\narguments :", arguments)
  code_erreur, message_erreur, dict_arguments = aster_homard_1 (arguments)
###  print ("dans", __name__, "\ndict_arguments = ", dict_arguments)
#
  verbose = dict_arguments["verbose"]
#
# 3. On passe dans le sous-repertoire de calcul pour homard
#
  if not code_erreur :
    rep_calc_logiciel = dict_arguments ["rep_calc_LOGICIEL"]
    if verbose :
      message_info += "\n.. rep_calc_logiciel :" + rep_calc_logiciel + "\n"
    try :
      os.chdir(rep_calc_logiciel)
    except OSError as err :
      print ("Probleme :\n", err)
      message_erreur  = "chdir vers le repertoire %s" % rep_calc_logiciel
      code_erreur = 2
#
# 4. Recuperation des options dans le fichier de configuration
#
  if not code_erreur :
    fic_conf = environnement["fic_conf"]
#    print (blabla, "2, :", "\nfic_conf :", fic_conf)
#    print (blabla, "2, :", "\nmessage_info :", message_info)
    code_erreur, message_info, message_erreur, variables_conf = aster_homard_2 (dict_arguments, fic_conf, message_info)
#
# 5. Copie des donnees avant l'adaptation
#
  if not code_erreur :
    if "rep_debug" in dict_arguments :
      code_erreur, message_info, message_erreur = aster_homard_6 (environnement, dict_arguments, variables_conf, "av", message_info)
#
# 6. Execution
#
  if not code_erreur :
###    print (blabla, "3, :", "\ndict_arguments :", dict_arguments, "\nvariables_conf :", variables_conf)
    code_erreur, code_retour_exec, message_info, message_erreur = aster_homard_3 (dict_arguments, variables_conf, message_info)
#
# 7. Manipulation sur les resultats produits
#
  if not code_erreur :
#    print (blabla, "4, :", "\nenvironnement :", environnement, "\ndict_arguments :", dict_arguments, "\nvariables_conf :", variables_conf, "\ncode_retour_exec :", code_retour_exec)
#    os.system("sleep 5")
#    print (blabla, "4, :", "\nmessage_info :", message_info)
    code_erreur, message_info, message_erreur = aster_homard_4 (environnement, dict_arguments, variables_conf, code_retour_exec, message_info)
    if code_retour_exec :
      code_erreur = 10
#
# 8. Copie des donnees apres l'adaptation
#
  if not code_erreur :
    if "rep_debug" in dict_arguments :
      code_erreur, message_info, message_erreur = aster_homard_6 (environnement, dict_arguments, variables_conf, "ap", message_info)
#
# 9. Apres une adaptation en mode perso, relance de HOMARD pour les figures
#
#  if not code_erreur :
#    if ( dict_arguments["PERSO"] == "oui" ) and ( variables_conf["ModeHOMA"] == 1 ) :
###      print (blabla, "5, :", "\nenvironnement :", environnement, "\ndict_arguments :", dict_arguments, "\nvariables_conf :", variables_conf)
#      code_erreur = aster_homard_5 (environnement, dict_arguments, variables_conf)
###      print ("en sortie de aster_homard_5, code_erreur =", code_erreur)
#
# 10. La fin
#
  os.chdir(rep_calc_aster)
###  os.system("sleep 3000")
  if ( code_erreur>0 and code_erreur<10 ) :
    saux  = "\nErreur de programmation de la macro-commande.\n"
    saux +=  "=============================================\n"
    message_erreur = saux + message_erreur
#
  return code_erreur, message_info, message_erreur
#
#
#=======================================================================================
#=======================================================================================
#
#
if __name__ == "__main__" :
#
  from .aster_homard_utilitaires import verif
#
# 1. ==> Recuperation des arguments
#
  T1 = "/tmp/q"
  T1_REFE = 1
  CODE_ERREUR, MESSAGE_INFO, MESSAGE_INFO = aster_homard (T1, "test")
  verif ("Test T1", T1_REFE, CODE_ERREUR)
#
  sys.exit(MESSAGE_INFO)
