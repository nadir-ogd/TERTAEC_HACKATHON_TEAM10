# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V2.08"
#
#
import os
#
#========================= Debut de la fonction ==================================
#
def exec_commande (arguments, verbose=0) :
#
  """
   Arguments :
     1. Nom de la commande a executer
     2. Mode verbeux ou non

   Au retour on a 0 si tout va bien, le code systeme sinon
  """
#gn  print ("Arguments a l'entree de", __name__, ":", arguments)
#
  message_erreur = ""
#
# 1. Execution
#
  commande = arguments[0:]
  erreur = os.system (commande)
#
# 2. La fin
#
  if erreur :
#
    try :
      message_erreur += os.strerror(erreur)
    except OSError as err :
      print (err)
#
    if verbose :
#
      message_erreur += "\nDans le repertoire : " + os.getcwd() + "\n"
#gn      print ("Contenu du repertoire :", os.listdir(os.getcwd()))
      message_erreur += "Erreur a l'execution de : " + commande + "\n"
      message_erreur += "Code de retour : " + str(erreur) + "\n"
#
    message_erreur += "\n"
#
  return erreur, message_erreur
#
#=========================  Fin de la fonction ===================================
#
#========================= Debut de la fonction ==================================
#
def verif (texte, reference, calcul):
#
  """
   Arguments :
     1. Texte a afficher
     2. Resultat de reference
     3. Resultat a comparer
  """
  #print ("Reference :", reference, type(reference))
  #print ("Calcul    :", calcul, type(calcul), "\n")
  bilan = "OK"
  if reference != calcul :
#
    if isinstance(calcul,dict) :
      for cle in reference:
        if cle not in calcul :
          print (cle, "est present dans la reference, mais pas dans le calcul.")
          bilan = "ECHEC"
        else :
          if reference[cle] != calcul[cle] :
            print ("Pour ", cle, " : Reference = ", reference[cle])
            print ("Pour ", cle, " : Calcul    = ", calcul[cle])
            bilan = "ECHEC"
      for cle in calcul:
        if cle not in reference :
          print (cle, "est present dans le calcul, mais pas dans la reference.")
          bilan = "ECHEC"
#
    elif isinstance(calcul,tuple) :
      if len(reference) != len(calcul) :
        print ("Longueurs differentes :")
        print ("Reference :", reference)
        print ("Calcul    :", calcul, "\n")
        bilan = "ECHEC"
      else :
        for num in range(len(reference)) :
          if reference[num] != calcul[num] :
            print ("Pour ", num, " :")
            if isinstance(reference[num],dict) :
              for cle in reference[num]:
                if cle not in calcul[num] :
                  print (cle, "est present dans la reference, mais pas dans le calcul.")
                  bilan = "ECHEC"
                else :
                  if reference[num][cle] != calcul[num][cle] :
                    print ("Pour ", cle, " : Reference = ", reference[num][cle])
                    print ("Pour ", cle, " : Calcul    = ", calcul[num][cle])
                    bilan = "ECHEC"
              for cle in calcul[num] :
                if cle not in reference[num] :
                  print (cle, "est present dans le calcul, mais pas dans la reference.")
                  bilan = "ECHEC"
            else :
              print (". Reference = ", reference[num])
              print (". Calcul    = ", calcul[num])
              bilan = "ECHEC"
#
    elif isinstance(calcul,int) :
      if isinstance(reference,str) :
        if reference != "%d" % calcul :
          bilan = "ECHEC"
#
    else :
      bilan = "ECHEC"
#
  if ( bilan == "ECHEC" ) :
    print ("Reference :", reference)
    print ("Calcul    :", calcul, "\n")
#
  print (texte, " : ", bilan, "\n")
#
#=========================  Fin de la fonction ===================================
#========================= Debut de la fonction ==================================
#
def int_to_str2 (entier) :
#
  """
Transforme un entier positif en une chaine d'au moins deux caracteres
  """
#
#  print ("\nArguments a l'entree de", __name__, ":", entier)
#
  if type(entier) == type(0) :
    la_chaine = '%02d' % entier
  else :
    la_chaine = None
#
  return la_chaine
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  L1 = "ls -ltr $HOME"
  L1_REFE = (0, '')
  L1_CALC = exec_commande(L1)
  print (L1_CALC)
  verif ("Test sur exec_commande avec "+L1, L1_REFE, L1_CALC)
#
  I2 = 2
  L2_REFE = "02"
  L2_CALC = int_to_str2(I2)
  print (L2_CALC)
  verif ("Test sur int_to_str2 avec I2=%d" % I2, L2_REFE, L2_CALC)
#
