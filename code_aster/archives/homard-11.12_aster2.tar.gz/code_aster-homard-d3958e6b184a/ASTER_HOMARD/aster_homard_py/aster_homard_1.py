# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
Decodage des arguments transmis
"""
__revision__ = "V2.12"
#
#
import platform, os
#
#========================= Debut de la fonction ==================================
#
def aster_homard_1 (arguments):
#
  """
   arguments obligatoires :
     1. Repertoire de reference de HOMARD sur la machine
     2. Sous-repertoire dans lequel aura lieu l'execution de homard
     3. Version de HOMARD
     4. Niveau d'information au sens ASTER
     5. Nom du fichier de donnees en mode information, 0 sinon
     N. rien, si version publique de HOMARD
        -PERSO, si version personnelle
     N. rien, si silencieux
        -verbose, sinon

   Remarque : ces arguments sont transmis sous forme d'une chaine de caracteres
  """
#
# 1. code de retour :
  blabla = "\nDans " + __name__ + " : "
  messages_erreur = { 0 : "", \
                      1 : "Il manque des arguments.", \
                      2 : "Il y a trop d'arguments.", \
                      3 : "La variable d'environnement HOMARD_USER n'est pas definie.", \
                      4 : "L'executable HOMARD est inconnu." }
#
# 2. Decodage et stockage des arguments :
###  print (blabla, arguments)
#
# 2.1. Verification du nombre
#
  l_arguments = arguments.split()
  nbarg = len(l_arguments)
  if nbarg < 5 :
    code_erreur = 1
  elif nbarg > 7 :
    code_erreur = 2
  else :
    code_erreur = 0
###  print ("l_arguments = ",l_arguments)
#
  dict_arguments = {}
  verbose = 0
#
  while not code_erreur :
#
# 2.2. Repertoire de reference de HOMARD sur la machine
#
    dict_arguments ["rep_refe_LOGICIEL"] = l_arguments[0]
#
# 2.3. Sous-repertoire dans lequel aura lieu l'execution de homard
#
    dict_arguments ["rep_calc_LOGICIEL"] = l_arguments[1]
#
# 2.4. Version de HOMARD
#
    nuvers = l_arguments[2]
    dict_arguments ["nuvers"] = nuvers
#
# 2.5. Niveau d'information au sens ASTER
#      Attention : on a au moins 2 du fait de EXEC_LOGICIEL
#
    dict_arguments ["nivinf"] = int(l_arguments[3])
    if dict_arguments ["nivinf"] > 3 :
      verbose = 2
    elif dict_arguments ["nivinf"] > 2 :
      verbose = 1
#
# 2.6. Nom du fichier de donnees, ou '0' si c'est sans objet
#
    dict_arguments ["fic_donn"] = l_arguments[4]
#
# 2.7. Est-ce une version personnelle ?
#
    dict_arguments ["PERSO"] = "non"
#
    for n_aux in range(5, len ( l_arguments ) ) :
#      print (l_arguments[n_aux])
#
      if l_arguments[n_aux] == "-PERSO" :
#
        dict_arguments ["PERSO"] = "oui"
        daux = os.environ
        if "HOMARD_HOME" in daux :
          repaux = os.path.join(daux["HOMARD_HOME"], "trunk", "bin")
          dict_arguments ["rep_pers_LOGICIEL"] = repaux
        else :
          code_erreur = 3
          break
#
      elif l_arguments[n_aux] == "-verbose" :
#
        verbose = 1
#
      else :
#
        dict_arguments ["rep_debug"] = l_arguments[n_aux]
#
    if code_erreur :
      break
#
# 3. On en deduit l'executable HOMARD
#
    system = platform.uname()[0]
    arch = platform.uname()[4]
    rep_loc = system
    if arch == "AMD64" or arch == "x86_64" or arch == "ia64" :
      rep_loc = rep_loc + "64"
#
    if dict_arguments["PERSO"] == "oui" :
      rep_base_logiciel = dict_arguments["rep_pers_LOGICIEL"]
      executable = os.path.join(rep_base_logiciel, "HOMARD.out")
    else :
      rep_base_logiciel = dict_arguments["rep_refe_LOGICIEL"]
      ajout = "HOMARD_"+nuvers+".out"
      executable = os.path.join(rep_base_logiciel, rep_loc, ajout)
#
    dict_arguments["executable"] = executable
#
    if not os.path.isfile(executable) :
      message_erreur  = "\nFichier " + executable
      code_erreur = 4
      break
#
#
    break
#
# 4. La fin
#
  dict_arguments ["verbose"] = verbose
#
  dict_arguments ["code_de_retour"] = code_erreur
###  print (dict_arguments)
  if code_erreur :
    saux =  blabla + "erreur de programmation\n" + messages_erreur[code_erreur]
    if code_erreur == 4 :
      saux += message_erreur
  else :
    saux = ""
#
  return code_erreur, saux, dict_arguments
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
#
  L1 = "1"
  L1_REFE = (1, "\nDans __main__ : erreur de programmation\nIl manque des arguments.", {'code_de_retour': 1, 'verbose': 0})
  L1_CALC = aster_homard_1 (L1)
  verif ("Test sur L1", L1_REFE, L1_CALC)
#
  L2 = "/tmp /tmp/tmp V10.n 1 toto"
  L2_REFE = (4, "\nDans __main__ : erreur de programmation\nL'executable HOMARD est inconnu.\nFichier /tmp/Linux64/HOMARD_V10.n.out", \
    {'executable': '/tmp/Linux64/HOMARD_V10.n.out', 'verbose': 0,  \
    "rep_refe_LOGICIEL": "/tmp", \
     "fic_donn": "toto", \
     "PERSO": "non",  \
    "rep_calc_LOGICIEL": "/tmp/tmp", \
     "code_de_retour": 4, \
     "nivinf": 1, \
     "nuvers": "V10.n"})
  L2_CALC = aster_homard_1 (L2)
  verif ("Test sur L2", L2_REFE, L2_CALC)
#
  L3 = "/tmp /tmp/tmp V10.n 1 toto -PERSO /tmp/tmpperso"
  L3_REFE = (0, "", \
    {"executable": "/home/D68518/HOMARD_SVN/trunk/bin/HOMARD.out", \
     "rep_refe_LOGICIEL": "/tmp", \
     "fic_donn": "toto", \
     "rep_pers_LOGICIEL": "/home/D68518/HOMARD_SVN/trunk/bin", \
     "PERSO": "oui", \
     "rep_calc_LOGICIEL": "/tmp/tmp", \
      "code_de_retour": 0, \
     "nivinf": 1, \
     "nuvers": "V10.n", \
     'verbose': 0, \
     "rep_debug": "/tmp/tmpperso",})
  L3_CALC = aster_homard_1 (L3)
  verif ("Test sur L3", L3_REFE, L3_CALC)
#
  L4 = "/tmp /tmp/tmp V10.n 1 toto -PERSO /tmp/tmpperso gabuzome"
  L4_REFE =  (2, "\nDans __main__ : erreur de programmation\nIl y a trop d'arguments.", {"code_de_retour": 2, 'verbose': 0})
  L4_CALC = aster_homard_1 (L4)
  verif ("Test sur L4", L4_REFE, L4_CALC)
