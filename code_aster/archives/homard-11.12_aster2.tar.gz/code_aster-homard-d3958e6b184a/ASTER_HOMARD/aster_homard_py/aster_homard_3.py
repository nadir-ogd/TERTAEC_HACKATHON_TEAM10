# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V2.14"
#
import os
#
from .aster_homard_utilitaires   import exec_commande
#
#========================= Debut de la fonction ==================================
#
def aster_homard_3 (dict_arguments, variables_conf, message_info="") :
#
  """
   Arguments :
     1. Dictionnaire des arguments generaux
     2. Dictionnaire des variables de configuration
     3. message_info : les messages d'information a completer
  """
#
# 1. code de retour :
  #blabla = "\nDans " + __name__ + " :"
  messages_erreur = { 0 : "",
                      1 : "Probleme a l'execution de HOMARD" }
  code_erreur = 0
  code_retour_exec = 0
  message_erreur = ""
#
  #print (blabla, "\ndict_arguments :", dict_arguments, "\nvariables_conf :", variables_conf)
#
  verbose = dict_arguments["verbose"]
  fic_donn = dict_arguments["fic_donn"]
#
# 2. Reperage de l'executable
#
  executable = dict_arguments["executable"]
#
# 3. Lancement
#
  if not code_erreur :
    commande = executable
    modehoma = variables_conf["ModeHOMA"]
    if modehoma == 2 :
      commande = commande + "<" + fic_donn
      if not verbose :
        commande = commande + "> /dev/null"
    if verbose :
      message_info += ".. Appel systeme pour " + commande
    print (message_info)
    code_retour_exec, saux = exec_commande (commande, verbose)
    if code_retour_exec :
      code_retour_exec = max(10, code_retour_exec)
#
# 4. La fin
#
  if code_erreur :
    message_erreur += messages_erreur[code_erreur]
  elif code_retour_exec:
    message_erreur += saux
    message_erreur += messages_erreur[1]
  else :
    message_erreur = ""
#
  return code_erreur, code_retour_exec, message_info, message_erreur
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
#
  COMMANDE = "echo 'toto'"
  D1 = {"verbose" : 1, "fic_donn" : "DONN", "executable" : COMMANDE }
  V1 = {'ModeHOMA': 1 }
  M1 = ""
  L1_REFE = (0, 0, ".. Appel systeme pour %s" % COMMANDE, "")
  L1_CALC = aster_homard_3 (D1, V1, M1)
  verif ("Test sur L1", L1_REFE, L1_CALC)
#
  D2 = {"verbose" : 1, "fic_donn" : "DONN", "executable" : "HOMARD.Configuration" }
  V2 = {'ModeHOMA': 2 }
  M2 = ""
  L2_REFE = (0, 32512 )
  L2_CALC = aster_homard_3 (D2, V2, M2)
  if ( L2_CALC[0] or L2_CALC[1] ) :
    print ("L2_CALC =", L2_CALC)
  verif ("Test sur L2", L2_REFE[1], L2_CALC[1])
#
  FIC_CONF_TEST = "HOMARD.Configuration"
  with open(FIC_CONF_TEST, "w") as FICHIER_TEST :
    SAUX = "ModeHOMA 1\n"
    FICHIER_TEST.write(SAUX)
  D3 = {"verbose" : 1, "fic_donn" : "DONN", "executable" : FIC_CONF_TEST }
  A3 = {'PERSO': "oui", 'rep_pers_LOGICIEL': '/local/HOMARD'}
  V3 = {'ModeHOMA': 1 }
  M3 = ""
  L3_REFE = (0, 32256 )
  L3_CALC = aster_homard_3 (D3, V3, M3)
  if ( L3_CALC[0] or L3_CALC[1] ) :
    print ("L3_CALC =", L3_CALC)
  verif ("Test sur L3", L3_REFE[1], L3_CALC[1])
  os.remove(FIC_CONF_TEST)

