# -*- coding: utf-8 -*-
"""
Programme du couplage entre HOMARD et Code_Aster
"""
__revision__ = "V2.15"
#
#
import platform, os
import tempfile
#
from .aster_homard_utilitaires   import exec_commande
from .aster_homard_utilitaires   import int_to_str2
#
###TEST###from aster_homard_utilitaires   import exec_commande
#
#========================= Debut de la fonction ==================================
#
def aster_homard_5 (environnement, dict_arguments, variables_conf) :
#
  """
   Arguments :
     1. Environnement : nom du fichier de configuration et nom du fichier de donnees
     2. Dictionnaire des options produites par aster_homard
     3. Code de retour de l'execution de HOMARD
  """
#
# 1. code de retour :
  blabla = "\nDans " + __name__ + " :"
  messages_erreur = { 0 : "Tout va bien", \
                      1 : "Destruction imposible.", \
                     10 : "Probleme a l'execution de HOMARD ; code de retour :" }
#
###  print (blabla, environnement, dict_arguments, variables_conf)
  erreur = 0
  verbose = dict_arguments["verbose"]
#
  if verbose :
    print (blabla)
    print (".. Repertoire d'execution de HOMARD : ", os.curdir)
    print (".. Fichiers presents dans ce repertoire :\n", os.listdir(os.curdir))
#
  l_fic_temp = list()
  while not erreur :
#
    niter = int(variables_conf["NumeIter"])
    niterp1 = niter + 1
    aux_niterp1 = int_to_str2(niterp1)
    rep_base_logiciel = dict_arguments["rep_pers_LOGICIEL"]
    nuvers = dict_arguments["nuvers"]
#
# 2. Creation du fichier de configuration
#
    fic_conf = environnement["fic_conf"]
    if os.path.isfile (fic_conf) :
      erreur = os.remove(fic_conf)
    if erreur :
      print ("Fichier ", fic_conf)
      erreur = 1
      break
#
    with open(fic_conf, "w") as fichier :
      fichier.write("ModeHOMA 2\n")
      fichier.write("CCAssoci HOMARD\n")
      fichier.write("CCNoMN__ "+variables_conf["CCNoMN__"]+"\n")
      fichier.write("HOMaiNP1 "+variables_conf["HOMaiNP1"]+" "+variables_conf["HOMaiNP1_fic"]+"\n")
      fichier.write("ListeStd Liste."+aux_niterp1+".info\n")
#
# 3. Creation d'un fichier de donnees qui ne fait rien de special
#
    saux = " 0\n 0\n q\n"
    t_aux = tempfile.mkstemp()
    fic_donn = t_aux[1]
    with open(fic_donn, "w") as fichier :
      fichier.write(saux)
    l_fic_temp.append(fic_donn)
#
# 4. Impression d'informations
#
    verbose = dict_arguments["verbose"]
    if verbose :
      liste = [fic_conf, fic_donn ]
    else :
      liste = []
#
    for fic in liste :
      if os.path.isfile (fic) :
        print (".... fichier :", fic)
        with open(fic, "r") as fichier :
          tout = fichier.read()
        print (tout)
#
# 5. Lancement de HOMARD
#
    if verbose :
      t_aux = tempfile.mkstemp()
      fic_aux = t_aux[1]
      l_fic_temp.append(fic_aux)
    else :
      fic_aux = "/dev/null"
#
    system = platform.uname()[0]
    arch = platform.uname()[4]
    rep_loc = system
    if arch == "AMD64" or arch == "x86_64" :
      rep_loc = rep_loc + "64"
    executable = os.path.join(rep_base_logiciel, nuvers, "bin", rep_loc, "HOMARD.out")
#
    commande = executable + "<" + fic_donn + ">" + fic_aux
    if verbose :
      print (".. Appel systeme pour", commande)
    erreur, saux = exec_commande (commande, verbose)
    if erreur :
      erreur = 10
      break
#
    if verbose :
      if os.path.isfile (fic_aux) :
        with open(fic_aux, "r") as fichier :
          tout = fichier.read()
        print (tout)
#
    break
#
# 6. Menage
#
  for fic in l_fic_temp :
    os.remove(fic)
#
# 7. La fin
#
  if erreur :
    print (blabla, messages_erreur[10], erreur)
    erreur = 10
#
  return erreur
#
#=========================  Fin de la fonction ===================================
#
#=========================      Auto-test      ===================================
#
if __name__ == '__main__' :
#
  from .aster_homard_utilitaires import verif
#
  E1 = { "fic_donn" : "DONN", "fic_conf" : "HOMARD.Configuration" }
  A1 = {"verbose" : 1, 'nuvers': 'V11.n', 'rep_pers_LOGICIEL': '/home/D68518/HOMARD_SVN/trunk'}
  V1 = {'NumeIter': '3', 'HOMaiNP1': 'MAI4', 'HOMaiNP1_fic': 'MAILL.4.HOM', 'CCNoMN__': 'MAILL_03', 'PPBasFic': 'INFO', 'ListeStd': '/tmp/gabuzome'}
  L1_REFE = 10
  L1_CALC = aster_homard_5 (E1, A1, V1)
  verif ("Test sur L1", L1_REFE, L1_CALC)
