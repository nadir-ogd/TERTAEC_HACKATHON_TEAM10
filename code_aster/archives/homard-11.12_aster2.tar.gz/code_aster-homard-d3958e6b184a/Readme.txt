                    How install HOMARD ?
                    ====================


1. Information
==============

The free downloading of HOMARD software is only allowed for coupling with Code_Aster. Please contact HOMARD project: homard[at]edf.fr
Visit the site: http://www.code-aster.org/outils/homard/menu_homard.en.htm for a description of HOMARD.
HOMARD is a trade mark of Electricit� de France.


2. Description of the package
=============================

The HOMARD package includes:
. the load module HOMARD
. coupling script between Code_Aster and HOMARD ;
. test cases ;
. an installation script.


3. Installation
===============

3.1. Prerequisite
-----------------
. Code_Aster should be installed.
. the absolute name of 'config.txt' files for Code_Aster.
  usually, it is $ASTER_ROOT/xxx/config.txt, with NEW11, STA11, etc. as xxx.
. this installation script and the archive directories must stay in the same directory.

3.2. How ?
----------
The installation is launched by:
python setup_homard.py -en

Names will be asked for:
. the absolute name of 'config.txt' file for Code_Aster. File existence is checked.

Options:
 -en   : for english messages ; the default is french.
  -v   : more information
  -vmax: much more information

3.3. What is done during the installation ?
-------------------------------------------
The script:
. extracts the load module HOMARD and the coupling scripts with Code_Aster from the archive file to the installation directory ;
. launches the test cases ;
. adapts the main coupling script, "homard", to the installation characteristics ;
. writes a final diagnosis.


========================================================

Copyright EDF - R&D - 1996, 1997, 2012
