Linked into target 'mc_icoco' library. 

The files below are part of the official ICoCo API and should NOT be modified:
    - ICoCoField.h
    - ICoCoField.hxx
    - ICoCoField.cxx
    - ICoCoMEDDoubleField.h
    - ICoCoMEDDoubleField.hxx
    - ICoCoMEDIntField.h
    - ICoCoMEDIntField.hxx

Their official version can be found in the TRUST repository:

    https://github.com/cea-trust-platform/icoco-coupling
