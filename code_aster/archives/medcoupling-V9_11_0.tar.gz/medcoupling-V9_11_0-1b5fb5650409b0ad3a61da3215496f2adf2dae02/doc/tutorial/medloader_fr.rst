
MEDLoader : lecture, écriture d'un fichier MED
==============================================

L'objectif de ces exercices est de comprendre comment lire et écrire un fichier MED.
 * Utilisation basique de l'API MEDLoader
 
   * Maillages
   * Champs
   
 * Utilisation avancée de l'API MEDLoader
 
   * Maillages
   * Champs
   
 * Exemple de manipulation classique de fichiers MED : splitter / fusionner un fichier MED suivant plusieurs sous-domaines
 
.. toctree::
   :maxdepth: 2

   medloader_basicAPI1_fr
   medloader_advancedAPI1_fr
   medloader_SplitAndMerge1_fr
