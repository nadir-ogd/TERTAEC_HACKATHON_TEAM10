from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modB", [(0.1, (5.2107 - 0.42706j)), (8.1, (5.2539 - 35.733j))]
)

check_complex_values(
    "imp_H.modB", [(0.1, (6.8565 - 0.64912j)), (8.1, (6.6404 - 40.589j))]
)

check_complex_values(
    "imp_R.modB", [(0.1, (4.3552 - 0.17218j)), (8.1, (2.5621 - 14.341j))]
)

check_complex_values(
    "imp_T.modB", [(0.1, (4.1077 - 0.072739j)), (8.1, (2.7738 - 6.5455j))]
)
