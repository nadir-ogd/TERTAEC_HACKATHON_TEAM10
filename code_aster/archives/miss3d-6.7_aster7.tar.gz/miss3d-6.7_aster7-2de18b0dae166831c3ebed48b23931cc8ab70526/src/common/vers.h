!M  COMMON VERCPU
!LATEXBEGIN
!LATEX variables generiques du programme
!LATEX\begin{itemize}
!LATEX \item \label{IVERS} IVERS :  INTEGER*8 type de version
!LATEX \item \label{ICRAY} ICRAY :  version cray
!LATEX \item \label{ISGI} ISGI :  version SGI
!LATEX \item \label{ISTD} ISTD :  version fortran standard
!LATEX \item \label{ICOMPAQ} ICOMPAQ :  version COMPAQ
!LATEX \item \label{IIBM} IIBM :  version IBM
!LATEX \item \label{IMACOSX} IMACOSX :  version MACOSX (double PRECISION)
!LATEX \item \label{IMACGNU} IMACgnu :  version MAC gnu (DOUBLE PRECISION)
!LATEX \item \label{IMAxlf} IMACxlf :  version MAC XLF (DOUBLE PRECISION)
!LATEX \item \label{ILINUX} ILINUX :  version LUNIX (DOUBLE PRECISION)
!LATEX \item \label{IALTIX} ILINUX :  version altix (DOUBLE PRECISION)
!LATEX\end{itemize}
!LATEXEND

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

    INTEGER*8 :: ivers,icray,isgi,istd,iibm,icompaq,imacosx,ilinux
    INTEGER*8 :: istddp,imacsp,ilinsp,imacgnu,nvermx,imacxlf,ialtix
    INTEGER*8 :: ibull,ilinux2
    parameter (nvermx=14)
    parameter (icray=1)
    parameter (istd =0)
    parameter (isgi =2)
    parameter (iibm =3)
    parameter (icompaq =4)
    parameter (imacosx =5)
    parameter (imacsp =7)
    parameter (imacgnu =10)
    parameter (imacxlf =11)
    parameter (ilinux =6)
    parameter (ilinsp =8)
    parameter (istddp =9)
    parameter (ialtix =12)
    parameter (ibull =13)
    parameter (ilinux2 =14)
    COMMON /VERCPU/   ivers

