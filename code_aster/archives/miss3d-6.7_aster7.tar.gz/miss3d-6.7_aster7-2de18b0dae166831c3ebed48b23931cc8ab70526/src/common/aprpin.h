!M  COMMON APRPIN
!LATEXBEGIN
!LATEX Variables pour preparer l'intepolation des fonctions de Green du milieu stratifie.
!LATEX\begin{itemize}
!LATEX \item \label{PORDSI} PORDS :  numero points sources ranges par ordre d'altitude decroissante,
!LATEX \item \label{PORDS} PORDSI :  pointeur inverse de PORDS,
!LATEX \item \label{PNPTS} PNPTS :  nombre de points sources entre deux niveaux sources successifs ,
!LATEX \item \label{PWZS} PWZS :  coefficients d'interpolation par rapport a l'altitude pour les sources,
!LATEX \item \label{PWZGG} PWZGG :  coefficients d'interpolation par rapport a l altitude pour les points de gauss grossiers,
!LATEX \item \label{PORDGG} PORDGG :  numero des points de gauss grossiers ranges par ordre d'altitude decroissante,
!LATEX \item \label{PNPTGG} PNPTGG :  nombre de points de gauss grossiers entre deux niveaux source successif,
!LATEX \item \label{PWZF} PWZF :  coefficient d'interpolation par rapport a l'altitude pour les points de gauss fins,
!LATEX \item \label{PORDGF} PORDGF :  numero des points de gauss fins ranges par ordre d altitude decroissante,
!LATEX \item \label{PNPTGF} PNPTGF :  nombre de points de gauss fins entre deux niveaux source
!LATEX \item \label{PWZL} PWZL :  coefficient d'interpolation par rapport a l'altitude pour les points de gauss fins,
!LATEX \item \label{PORDGL} PORDGL :  numero des points de gauss fins ranges par ordre d altitude decroissante,
!LATEX \item \label{PNPTGL} PNPTGL :  nombre de points de gauss fins entre deux niveaux source
!LATEX \item \label{PWFR} PWFR :  poids sur les sources,
!LATEX \item \label{PELTF} PORDG :  �lement associ� � une source
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 ::     PORDS ,PNPTS ,PWZS  ,PWZGG ,PORDGG,PNPTGG,PWZGF , &
    PORDGF,PNPTGF,PORDSI,PWZGL , &
    PORDGL,PNPTGL,PWFR,PELTF,PNPTLC,PNPTL2
    COMMON /APRPIN/ PORDS ,PNPTS ,PWZS  ,PWZGG ,PORDGG,PNPTGG,PWZGF , &
    PORDGF,PNPTGF,PORDSI,PWZGL , &
    PORDGL,PNPTGL,PWFR,PELTF,PNPTLC,PNPTL2
