!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{PPROP} PPROP :  proprietes des materiaux <DOS2M> INSOL/INIMAT
!LATEX                                1 -> RO
!LATEX                                 2 -> VP**2 CARRE VITESSE ONDES P
!LATEX                                 3 -> VS**2 CARRE VITESSE ONDES S
!LATEX                                 4 -> AMORT. HYSTER.  BETA
!LATEX                                 5 -> AMORT. VISQUEUX ETA
!LATEX \item \label{PLMAT} PLMAT :  numero du materiau des couches <DOS2M> INISOL/INICCH
!LATEX \item \label{PHCOU} PHCOU :  hauteur des couches <DOS2M> INISOL/INICCH
!LATEX \item \label{PZCCH} PZCCH :  altitude des couches <DOS2M> INIDOS
!LATEX \item \label{PNCDIS} PNCDIS :  numero de la couche des recepteurs <DOS2M> INIDOS
!LATEX \item \label{PCDISP} PCDISP :  numero recepteur d'une couche INISOL INICCH
!LATEX \item \label{PCSRC} PCSRC :  numero de la couche des sources <DOS2M> INIDOS
!LATEX \item \label{PITYP} PITYP :  type de source
!LATEX \item \label{PGEOS} PGEOS :  geometrie de la source
!LATEX \item \label{PLINTR} PLINTR :  type d'interface
!LATEX \item \label{PNDISR} PNDISR :  numero du deplacement au niveau de la source
!LATEX \item \label{PZDISP} PZDISP :  altitude des recepteurs <DOS2M> INIDOS
!LATEX \item \label{PZSRC} PZSRC :  altitude des sources <DOS2M> INIDOS
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 ::         PPROP ,PLMAT ,PHCOU ,PNCDIS,PCDISP,PCSRC,PITYP , &
    PGEOS ,PLINTR,PNDISR,PZCCH ,PZDISP,PZSRC
    COMMON /DIMEL0/ PPROP ,PLMAT ,PHCOU ,PNCDIS,PCDISP,PCSRC,PITYP , &
    PGEOS ,PLINTR,PNDISR,PZCCH ,PZDISP,PZSRC
