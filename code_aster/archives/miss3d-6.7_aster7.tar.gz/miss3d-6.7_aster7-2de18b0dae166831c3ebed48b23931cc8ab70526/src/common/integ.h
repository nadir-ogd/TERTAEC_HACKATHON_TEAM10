!M  COMMON INTEGR
!LATEXBEGIN
!LATEX Les parametres d integration sur le  maillage
!LATEX \item \label{NREC1} NREC1 : nombre de points de gauss grossiers sur les rectangles
!LATEX \item \label{NREC2} NREC2 : nombre de points de gauss fins      sur les rectangles
!LATEX \item \label{NTRI1} NTRI1 : nombre de points de gauss grossiers sur les triangles
!LATEX \item \label{NTRI2} NTRI2 : nombre de points de gauss fins      sur les triangles
!LATEX \item \label{NSEG1} NSEG1 : nombre de points de gauss grossiers sur les segments
!LATEX \item \label{NSEG2} NSEG2 : nombre de points de gauss fins      sur les segments
!LATEX \item \label{NBG1} NBG1 : nombre de points de gauss grossiers sur le maillage
!LATEX \item \label{NBG2} NBG2 : nombre de points de gauss fins      sur le maillage
!LATEX \item \label{NBG1T} NBG1T : nombre de points de gauss grossiers sur le maillage surfacique
!LATEX \item \label{NBG2T} NBG2T : nombre de points de gauss fins      sur le maillage surfacique
!LATEX \item \label{MXGE1} MXGE1 : nombre max de points de gauss grossiers sur un element du maillage
!LATEX \item \label{MXGE2} MXGE2 : nombre max de points de gauss fins      sur un element du maillage
!LATEXEND
    INTEGER*8 ::      NREC1,NREC2,NTRI1,NTRI2,nseg1,nseg2, &
    NBG1,NBG2,nbrec,nbtri,nbseg,mxge1,mxge2, &
    NTET1,NTET2,NBTET,NBPRI,NBPNT, &
    NBHEX,maxint,nbg1t,nbg2t
    COMMON /INTEGR/ NREC1,NREC2,NTRI1,NTRI2,nseg1,nseg2, &
    NBG1,NBG2,nbrec,nbtri,nbseg,mxge1,mxge2, &
    NTET1,NTET2,NBTET,NBPRI,NBPNT, &
    NBHEX,maxint,nbg1t,nbg2t
