!M  COMMON FREQ
!LATEXBEGIN
!LATEX Variables relatives a la frequence
!LATEX\begin{itemize}
!LATEX \item \label{NFREQ} NFREQ :  INTEGER*8 nombre de frequences ( INPUT )
!LATEX \item \label{IFREQ} IFREQ :  INTEGER*8 numero de la frequence courante
!LATEX \item \label{FREQ} FREQ :  REAL*4  frequence courante
!LATEX \item \label{FRQMIN} FRQMIN :  REAL*4  frequence inferieure
!LATEX \item \label{DFREQ} DFREQ :  REAL*4  pas en frequence ( INPUT )
!LATEX \item \label{OMEGA} OMEGA :  REAL*4  pulsation courante
!LATEX \item \label{OMEGAL} OMEGAL :  REAL*8 pulsation maxi
!LATEX \item \label{IMGOMG} IMGOMG :  REAL*8 partie imaginaire de la pulsation
!LATEX \item \label{VFREQ} VFREQ :  REAL*8 Valeurs des frequences de calcul
!LATEX \item \label{COMEGA} COMEGA :  REAL*8 pulsation complexe
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: nfrqmx
    parameter (nfrqmx=10000)
    INTEGER*8 :: NFREQ,IFREQ,ifrqdb,ifrbcl,iFRqfi
    REAL*8 ::  FREQ,FRQMIN,DFREQ,OMEGA,OMEGA1,DOMEGA,omegal,frqmax
    REAL*8 ::  imgomg
    REAL*8 :: vfreq(nfrqmx)
    COMPLEX*16 comega
    COMMON /CMFREQ/ FREQ,NFREQ,IFREQ,FRQMIN,DFREQ,OMEGA, &
    ifrqdb,ifrbcl,iFRqfi,OMEGA1,DOMEGA,omegal, &
    frqmax,imgomg,vfreq,comega

