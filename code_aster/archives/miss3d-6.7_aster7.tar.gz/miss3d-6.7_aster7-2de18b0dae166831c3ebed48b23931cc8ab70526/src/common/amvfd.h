!M  COMMON AMVFD
!LATEXBEGIN
!LATEX Variables pour le calcul du mouvement sismique induit
!LATEX
!LATEX \begin{itemize}
!LATEX \item \label{PIMP} PIMP : Impedance,
!LATEX \item \label{PFRC} PFRC : Force equivalente
!LATEX \item \label{PTDM} PTDM : Champs de "contraintes" diffractes locaux
!LATEX \item \label{PKEXT} PKEXT : Impedance exterieure
!LATEX \item \label{PUTOT} PUTOT : Champs de "deplacements" diffractes totaux
!LATEX \item \label{PTTOT} PTTOT : Champs de "contraintes" diffractes totaux
!LATEX \item \label{PD0} PD0 : Champs de "contraintes" reflechis locaux
!LATEX \item \label{PD0CTR} PD0CTR : UD0 sur elts volumiques par MVFOND
!LATEX \end{itemize}
!LATEX
!LATEXEND

    INTEGER*8 :: PIMP,PFRC,PTDM,PKEXT,PUTOT,PTTOT,PD0, pd0ctr

    COMMON /AMVFD/  PIMP,PFRC,PTDM,PKEXT,PUTOT,PTTOT, &
    PD0,pd0ctr
