!M  COMMON HORIZ
!LATEXBEGIN
!LATEX Param�tres de l'�chantillonnage horizontale des fonctions de Green du stratifi�.
!LATEX\begin{itemize}
!LATEX \item \label{ND} ND : nombre de points pour la FFT ou FHT en espace,
!LATEX \item \label{X1} X1 : premier offset courant,
!LATEX \item \label{DX} DX : pas d'offset courant,
!LATEX \item \label{RNDNN} RNDNN : 
!LATEX \item \label{NL} NL : nombre d'offset courant,
!LATEX \item \label{XREF} XREF : distance caract�ristique, 
!LATEX \item \label{NL2} NL2 : nombre d'offset �chantillonnage 2,
!LATEX \item \label{NL1} NL1 : nombre d'offset �chantillonnage 1,
!LATEX \item \label{X12} X12 : premier offset �chantillonnage 2,
!LATEX \item \label{DX2} DX2 : pas d'offset �chantillonnage 2,
!LATEX \item \label{X11} X11 : premier offset �chantillonnage 1,
!LATEX \item \label{DX1} DX1 : pas d'offset �chantillonnage 1,
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8  ND,NL,NL2,NL1
      REAL*8 X1,DX,RNDNN,XREF,X12,DX2,X11,DX1
      COMMON /HORIZ/  ND,X1,DX,RNDNN,NL,XREF,NL2,NL1,X12,DX2,X11,DX1
