      include '../aindos.h'
!M  COMMON DIMEL
!LATEXBEGIN
!LATEX variables pour le calcul des coef. refl. trans. par la m�thode de Kenneth.
!LATEX\begin{itemize}
!LATEX \item \label{PCMU  }PCMU    : $\mu$
!LATEX \item \label{PCVS  } PCVS   : $c_s$
!LATEX \item \label{PCVS2 } PCVS2 : $c_s^2$
!LATEX \item \label{PCVP2 } PCVP2 : $c_p^2$
!LATEX \item \label{PCEPMT} PCEPMT : normes vecteurs ondes P,
!LATEX \item \label{PCESMT} PCESMT : normes vecteurs ondes S,
!LATEX \item \label{PCRCPM} PCRCPM : nombre d'onde vertical  ondes P,
!LATEX \item \label{PCSCSM} PCSCSM : ombre d'onde vertical ondes S,
!LATEX \item \label{PCMNPS}PCMNPS  : Matrices M,N $(U=M^\pmV^\pm,T=N^\pmV^\pm)$ P-SV,
!LATEX                      CMNPSV (NKS,1...4,IMAT)  : $M^+$
!LATEX                             (NKS,5...8,IMAT)  : $M^-$
!LATEX                             (NKS,9...16,IMAT) : $N^+$ et $N^-$
!LATEX \item \label{PCMNSH} PCMNSH : Matrices M,N ($U=M^\pmV$) SH
!LATEX                      CMNSH  (NKS,1,IMAT)      : $M^+$
!LATEX                             (NKS,2,IMAT)      --> $M^-$
!LATEX                             (NKS,3...4,IMAT)  --> $N^+$ et $N^-$
!LATEX \item \label{PCTRPS} PCTRPS : coef. refl. interface P-SV,
!LATEX \item \label{PCTRSH} PCTRSH : coef. refl. interface SH,
!LATEX \item \label{PCTRAN} PCTRAN : coef. trans. d'une couche,
!LATEX \item \label{PQUFPS} PQUFPS : coef. refl. global sur la surface libre P-SV,
!LATEX \item \label{PQUFSH} PQUFSH : coef. refl. global sur la surface libre SH,
!LATEX \item \label{PRDBPS} PRDBPS : coef. refl. global sur le bedrock libre P-SV, 
!LATEX \item \label{PRDBSH} PRDBSH :  coef. refl. global sur le bedrock libre SH,
!LATEX \item \label{PQRUPS} PQRUPS  : coef. refl. global source r�cepteur P-SV haut,
!LATEX \item \label{PQRDPS} PQRDPS : coef. refl. global source r�cepteur P-SV bas, 
!LATEX \item \label{PQTUPS} PQTUPS : coef. trans. global source r�cepteur P-SV haut,
!LATEX \item \label{PQTDPS} PQTDPS : coef. trans. global source r�cepteur P-SV bas,
!LATEX \item \label{PQRUSH} PQRUSH : coef. refl. global source r�cepteur SH haut,
!LATEX \item \label{PQRDSH} PQRDSH : coef. refl. global source r�cepteur SH bas,
!LATEX \item \label{PQTUSH} PQTUSH : coef. trans. global source r�cepteur SH haut,
!LATEX \item \label{PQTDSH} PQTDSH : coef. trans. global source r�cepteur SH bas,
!LATEX \item \label{PCVSUP} PCVSUP : vecteur d'onde montant $V^+$ P-SV,
!LATEX \item \label{PCVSDP} PCVSDP : vecteur d'onde descendant $V^-$ P-SV, 
!LATEX \item \label{PCVSUS} PCVSUS : vecteur d'onde montant $V^+$ SH, 
!LATEX \item \label{PCVSDS} PCVSDS : vecteur d'onde descendant $V^-$ SH,
!LATEX \item \label{PCSIGM} PCSIGM : discontinuit� du vecteur d'onde au niveau de la source,
!LATEX \item \label{PRES}    PRES  : vecteur de travail,
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8         PCMU  ,PCVS  ,PCVS2 ,PCVP2 ,&
                     PCEPMT,PCESMT,PCRCPM,PCSCSM,PCMNPS,PCMNSH,PCTRPS,&
                     PCTRSH,PCTRAN,PQUFPS,PQUFSH,PRDBPS,PRDBSH,PQRUPS,&
                     PQRDPS,PQTUPS,PQTDPS,PQRUSH,PQRDSH,PQTUSH,PQTDSH,&
                     PCVSUP,PCVSDP,PCVSUS,PCVSDS,PCSIGM,PRES
      COMMON /DIMEL/  PCMU  ,PCVS  ,PCVS2 ,PCVP2 ,&
                     PCEPMT,PCESMT,PCRCPM,PCSCSM,PCMNPS,PCMNSH,PCTRPS,&
                     PCTRSH,PCTRAN,PQUFPS,PQUFSH,PRDBPS,PRDBSH,PQRUPS,&
                     PQRDPS,PQTUPS,PQTDPS,PQRUSH,PQRDSH,PQTUSH,PQTDSH,&
                     PCVSUP,PCVSDP,PCVSUS,PCVSDS,PCSIGM,PRES
!M  COMMON DIMEL
!LATEXBEGIN
!LATEX Variables pour le calcul des d�placements et des contraintes dans l'espace physique.
!LATEX\begin{itemize}
!LATEX \item \label{PTRIGS} PTRIGS : facteurs trigo. pour la FFT,
!LATEX \item \label{PFACT} PFACT : poids d'int�gration $[0,2\pi]$,
!LATEX \item \label{PTAB} PTAB : tableau de travail pour l'int�gration � pas variables,
!LATEX \item \label{PCDISC} PCDISC : singularites au niveau de la source,
!LATEX \item \label{PCOEF1} PCOEF1 : coefficient pour le calcul des contraintes $2\rho\c_s^2$,
!LATEX \item \label{PCOEF2} PCOEF2 : coefficient pour le calcul des contraintes $1-c_s/c_p$,
!LATEX \item \label{PCOEF3} PCOEF3 : coefficient pour le calcul des contraintes $1-2 c_s/c_p$,
!LATEX \item \label{PMATDI} PMATDI : num�ro du mat�riau au niveau de la source.
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8         PTRIGS,PFACT,PTAB,PCDISC,PCOEF1,PCOEF2,PCOEF3,&
                     PMATDI
      COMMON /DIMEL2/ PTRIGS,PFACT,PTAB,PCDISC,PCOEF1,PCOEF2,PCOEF3,&
                     PMATDI
