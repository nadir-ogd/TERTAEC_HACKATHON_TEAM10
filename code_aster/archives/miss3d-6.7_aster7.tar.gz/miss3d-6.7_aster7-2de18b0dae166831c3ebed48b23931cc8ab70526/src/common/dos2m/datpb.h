!M  COMMON ADMAIN
!LATEXBEGIN
!LATEX pointeur globaux sur les modules
!LATEX\begin{itemize}
!LATEX \item \label{NDDL} NDDL : nombre de DDL DOS2M, pour les d�placements : 
!LATEX    $(u_xf_x,u_zf_x,u_yf_y,u_xf_z,u_zf_z)$, 
!LATEX    pour les contraintes $(\sigma_{zx}f_x,\sigma_{zz}f_x,\sigma_{zy}f_y,\sigma_{zx}f_z,\sigma_{zz}f_z)$ 
!LATEX    et $(\sigma_{xx}f_x,\sigma_{yy}f_x,\sigma_{xy}f_y,\sigma_{xx}f_z,\sigma_{yy}f_z)$
!LATEX \item \label{NCOUCH} NCOUCH : nombre de couches,
!LATEX \item \label{NCCH1} NCCH1 : NCOUCH+1,
!LATEX \item \label{NSOURC} NSOURC : nombre de sources,
!LATEX \item \label{NMAT} NMAT : nombre de mat�riaux,
!LATEX \item \label{NDISP} NDISP : nombre de r�cepteurs,
!LATEX \item \label{NINTRF} NINTRF : nombre d'interfaces physiques
!LATEX \item \label{LMNPSV} LMNPSV : taille des matrices M et N en PSV,
!LATEX \item \label{LMNSH} LMNSH :  taille des matrices M et N en SH,
!LATEX \item \label{Z0} Z0 : cote de la surface libre.
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8  NDDL,NCOUCH,NCCH1,NSOURC,NMAT,NDISP,IRIGID,NINTRF,&
                     LMNPSV,LMNSH
      REAL*8 Z0
      COMMON /DATPB/  NCOUCH,NCCH1,NSOURC,NMAT,NDISP,IRIGID,NINTRF,&
                     LMNPSV,LMNSH,Z0,NDDL
