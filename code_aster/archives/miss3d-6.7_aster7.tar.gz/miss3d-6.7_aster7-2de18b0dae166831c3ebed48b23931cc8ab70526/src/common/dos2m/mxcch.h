!M  COMMON MXCCH
!LATEXBEGIN
!LATEX Min et Max source et recepteurs :
!LATEX\begin{itemize}
!LATEX \item \label{MINSRC} MINSRC : numero de la couche contenant la source la plus basse,
!LATEX \item \label{MAXSRC} MAXSRC : numero de la couche contenant la source la plus haute,
!LATEX \item \label{MINRCP} MINRCP : numero  de la couche contenant le recepteur le plus bas,
!LATEX \item \label{MAXRCP} MAXRCP : numero  de la couche contenant le recepteur le plus haut,
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8  MINSRC,MAXSRC,MINRCP,MAXRCP
      COMMON /MXCCH/  MINSRC,MAXSRC,MINRCP,MAXRCP
