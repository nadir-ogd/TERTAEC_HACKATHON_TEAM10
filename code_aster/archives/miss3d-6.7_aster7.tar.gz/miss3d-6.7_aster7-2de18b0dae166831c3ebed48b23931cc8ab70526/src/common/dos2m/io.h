!M  COMMON IO
!LATEXBEGIN
!LATEX Fichiers temporaires DOS2M :
!LATEX\begin{itemize}
!LATEX \item \label{ITAP9} ITAP9   : unite de Fichier temporaires DOS2M,
!LATEX \item \label{ITAP10} ITAP10 : unite de Fichier  temporaires DOS2M,
!LATEX \item \label{ITAP30} ITAP30 : unite de Fichier  temporaires DOS2M.
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8   ITAP9,ITAP10,ITAP30
      COMMON /IO/     ITAP9,ITAP10,ITAP30
