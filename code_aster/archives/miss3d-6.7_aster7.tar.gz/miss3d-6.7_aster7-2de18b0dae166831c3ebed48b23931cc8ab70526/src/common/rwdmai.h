    INTEGER*8 :: isdoms,mxdom
    common /rwdmai/ isdoms,mxdom
