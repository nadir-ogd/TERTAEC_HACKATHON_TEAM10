! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                         REPERTOIRE COMMON                            C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
! SAVIN  5/06/98

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                                                                      C
!     COMMON DES VARIABLES POUR LA DECOMPOSITION DE KARHUNEN-LOEVE     C
!                                                                      C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                                                                      C
!        E. SAVIN                  LMSS/ECP                            C
!                                                                      C
!        REVISION :                                                    C
!                                                                      C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

!        pciter : facteurs de participation (ddls globaux) iteres
!        pimpgd : impedance du domaine perturbe non inversee
!        iiter  : ordre courant d'iteration
!        niter  : nombre total d'iterations
!        plaskl : assemblage sous-domaine par Karhunen-Loeve
!        pnbmkl : nombre de modes de Karhunen-Loeve par sous-domaine


    INTEGER*8 ::        pcokef,pcovef,pvapkl,pvepkl,itycov,n1cov,nparam, &
    nbmkl,nbmkl0,nbmklx,plcorr,pstdev,imkl
    INTEGER*8 ::        pnbmkl,plaskl,passkl,pklloi
    INTEGER*8 ::        pseed,ilprob
    REAL*8 ::           vpwrkl,vepskl,vepsk0,vlcorr(3,3),vstdev(3),vlmod, &
    vmodul(3)
    common /ikarh/ pcokef,pcovef,pvapkl,pvepkl,itycov,n1cov,nparam, &
    nbmkl,nbmklx,plcorr,pstdev,imkl
    common /vkarh/ vpwrkl,vepskl,vlcorr,vstdev,vlmod,vmodul
    common /iaskl/ pnbmkl,plaskl,passkl,pklloi
    parameter      (nbmkl0 = 1, vepsk0 = 2.e-01)
    common /imckl/ pseed,ilprob


    include '../common/iter.h'

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
