!M  COMMON AREUI
!LATEXBEGIN
!LATEX variables de calcul du champ incident
!LATEX       ( resultats stockees sur .UI et .TUI  )
!LATEX\begin{itemize}
!LATEX \item \label{PCHUIE} PCHUIE :  champ incident ( deplacement et contraintes ) RESUI/CALCUI
!LATEX \item \label{PTRUIU} PTRUIU :  tableau de travail deplacements RESUI
!LATEX \item \label{PTRUIT} PTRUIT :  tableau de travail contraintes RESUI
!LATEX \item \label{PUGKUI} PUGKUI :  tableau de travail < DOS2M > RESUI/INTRP.
!LATEX \item \label{PUGRSI} PUGRSI :  tableau de travail < DOS2M > RESUI/INTRP.
!LATEX\end{itemize}
!LATEXEND


    INTEGER*8 :: PCHUIE,PTRUIU,PTRUIT,PUGKUI,PUGRSI
    COMMON /AREUI/  PCHUIE,PTRUIU,PTRUIT,PUGKUI,PUGRSI

