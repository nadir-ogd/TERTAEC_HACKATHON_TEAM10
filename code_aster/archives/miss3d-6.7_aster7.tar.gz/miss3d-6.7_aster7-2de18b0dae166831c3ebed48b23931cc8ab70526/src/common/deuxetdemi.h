!M COMMON deuxetdemi
!LATEXBEGIN
!LATEX   common contenant : les variables pour le retour en espace,
!LATEX	les variables associees au modele 2.5D et aux symetries geometriques,
!LATEX  ainsi que la periodicite.
!LATEX
!LATEX Modele 2.5D
!LATEX\begin{itemize}
!LATEX \item  \label{DY}  DY : pas d'echantillonnage en Y (pour fft 2.5d)
!LATEX \item  \label{YMAX} ymax : offset maximal en y (pour fft 2.5d)
!LATEX \item  \label{DKP} dkp : pas en nombre d'onde en y (pour fft 2.5d)
!LATEX \item  \label{KMAX} kmax : nombre d'onde  en y maximal(pour fft 2.5d)
!LATEX \item  \label{KXMAX} kxmax : nombre d'onde  en x maximal(pour fft 2.5d)
!LATEX \item  \label{KK} kk : nombre d'onde en Y
!LATEX \item  \label{KKX} KKX : nombre d'onde en X
!LATEX \item  \label{KMIN} KMIN : nombre d'onde minimal en y
!LATEX \item  \label{KXMIN} KXMIN : nombre d'onde minimal en X
!LATEX \item  \label{DK} DK : pas du nombre d'onde minimal en Y
!LATEX \item  \label{DKX} DKX : pas du nombre d'onde minimal en X
!LATEX\end{itemize}
!LATEX
!LATEX Periodicite
!LATEX\begin{itemize}
!LATEX \item  \label{PERY} PERY : periodicite en y
!LATEX \item  \label{PERX} PERX : periodicite en x
!LATEX \item  \label{NCELX} NCELX : nombre de cellules x
!LATEX \item  \label{NCELY} NCELY : nombre de cellules y
!LATEX \item  \label{NCELX2} NCELX2 : nombre de paquets de cellules x
!LATEX \item  \label{NCELY2} NCELY2 : nombre de paquets de cellules y
!LATEX \item  \label{lmod} LOGICAL LMOD : indicateur sur la synthese modale
!LATEX \item  \label{NY}   INTEGER*8 NY : nombre de cellules pour la sommation
!LATEX \item  \label{ISYM} isym : type de symetrie
!LATEX\end{itemize}
!LATEX
!LATEX     Definition des sources mobiles
!LATEX\begin{itemize}
!LATEX \item  \label{VITSRC} vitsrc : vitesse de la source mobile
!LATEX \item  \label{FMINSRC} fminsr: frequence mini de la source mobile
!LATEX \item  \label{FMAXSRC} FMAXSRC : frequence maxi de la source mobile
!LATEX \item  \label{DFSRC} dfsrc : pas en frequence a la source
!LATEX \item  \label{FSRC} FSRC : frequence couante a la source
!LATEX \item  \label{NFSRC} nfsrc : nombre de frequences
!LATEX\end{itemize}
!LATEX     Fictitious eigenfrequencies
!LATEX\begin{itemize}
!LATEX \item  \label{HSCALE} hscale : distance between both boundaries
!LATEX \item  \label{ASCALE} hscale : damping factor
!LATEX\end{itemize}
!LATEXEND

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

    REAL*8 :: Dy,ymax
    REAL*8 :: dkp,kmax,kxmax
    REAL*8 :: KK,KMIN,DK,dkx,kxmin,kkx

! ullp21-03-02

    REAL*8 :: hscale,ascale
    REAL*8 :: pery,perx
    logical :: lmod
    INTEGER*8 :: NK,ny,ncelx,ncely,nkx,ncelx2,ncely2
    INTEGER*8 :: isym

    COMMON /foury/ Dy,ymax,dkp,kmax,KK,KMIN,dK, &
    pery,hscale,ascale,NK,Ny,isym, &
    kxmax,kxmin,dkx,nkx,perx,kkx,ncelx,ncely,ncelx2,ncely2, &
    lmod
    REAL*8 :: vitsrc,fminsr,fmaxsr,dfsrc,fsrc
    INTEGER*8 :: nfsrc

!     tableau de travail pour fft

    common /msour/vitsrc,fminsr,fmaxsr,dfsrc,NFsrc,fsrc


