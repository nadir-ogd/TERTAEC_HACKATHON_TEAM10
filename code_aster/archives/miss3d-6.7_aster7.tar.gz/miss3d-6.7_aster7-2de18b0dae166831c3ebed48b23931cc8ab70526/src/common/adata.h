!M  COMMON ADATA
!LATEXBEGIN
!LATEX pointeurs sur donnees du probleme
!LATEX\begin{itemize}
!LATEX \item \label{PXNOD} PXNOD :  coordonnees des noeuds, creation
!LATEX \item \label{PNODEL} PNODEL :  numero des noeuds des elements
!LATEX \item \label{PCHPLM} PCHPLM :  champs imposes aux noeuds
!LATEX \item \label{PGROUP} PGROUP :  groupe des elements,
!LATEX \item \label{PNODGR} PNODGR :  nombre de noeuds par groupe,
!LATEX \item \label{PELTGR} PELTGR :  nombre d elements par groupe,
!LATEX \item \label{PTRIN} PTRIN :  appartenance d un noeud a un groupe,
!LATEX \item \label{PMASK} PMASK :  type de condition aux limite sur les groupes,
!LATEX \item \label{PMODGR} PMODGR :  nombre de champs imposes par groupes,
!LATEX \item \label{PORDGR} PORDGR :  ordre de definition des groupes par l utilisateur,
!LATEX \item \label{PGRPCH} PGRPCH :  groupe sur lequel le champ est non nul,.true. -> non nul
!LATEX
!LATEX \item \label{PXCTR} PXCTR :  coordonnees des points de controle,
!LATEX \item \label{PXCTG} PXCTG :  coordonnees des points de controle globaux
!LATEX \item \label{PTYPGR} PTYPGR :  type de groupe,
!LATEX \item \label{PTYMOD} PTYMOD :  type de mode impose sur les groupes BEM,
!LATEX \item \label{PLSKBE} PLSKBE :  numero de l element ou s applique le champ BEM,
!LATEX \item \label{PIDDLG} PIDDLG :  tableau de correspondance des ddl,
!LATEX \item \label{PIDDL} PIDDL :  tableau de correspondance des ddl globaux,
!LATEX \item \label{PIEL} PIEL :  tableau de correspondance des elements,
!LATEX \item \label{PNCHDF} PNCHDF :  nombre de modes definis a chaque definition
!LATEX \item \label{PNGRDF} PNGRDF :  nombre de groupes impliques par un bloc de definition
!LATEX \item \label{PGREXT} PGREXT :  identificateur sur les groupes interieurs ($=0$) ou exterieur ($\neq0$), c'est la somme des pdfdom,
!LATEX \item \label{PCHEXT} PCHEXT :  numerotation des champs, on numerote d'abord les champs interieurs puis les champ exterieurs. Ce tableau sert aussi  d'identificateur s'il s'agit d'un champ interieur ou exterieur,=< nchint    mode interieur (support strictement interieur), > nchint    mode exterieur (au moins une partie du support exterieur)
!LATEX \item \label{PGREXD} PGREXD :  identificateur sur les groupes interieurs ou exterieur locaux,$=0$ groupe interieur, $\neq0$  groupe exterieur
!LATEX \item \label{PCHEXD} PCHEXD :  numerotation des champs, om numerote d'abord les champs interieurs puis les champ exterieurs. Ce tableau sert aussi d'identificateur s'il s'agit d'un champ interieur ou exterieur,=< nchint    mode interieur (support strictement interieur), > nchint    mode exterieur (au moins une partie du support exterieur)
!LATEX \end{itemize}
!LATEXEND


    INTEGER*8 ::     PXNOD,PNODEL,PCHPLM,PGROUP,PNODGR,PELTGR,PTRIN, &
    PMASK,PMODGR,PORDGR,PGRPCH,PXCTR,PTYMOD,PLSKBE, &
    PIDDL,PIDDLG,PIEL,PNCHDF,PNGRDF,PGREXT,PCHEXT, &
    PGREXD,PCHEXD,PTYPGR,pxctg,pinod
    COMMON /ADATA/  PXNOD,PNODEL,PCHPLM,PGROUP,PNODGR,PELTGR,PTRIN, &
    PMASK,PMODGR,PORDGR,PGRPCH,PXCTR,PTYMOD,PLSKBE, &
    PIDDL,PIDDLG,PIEL,PNCHDF,PNGRDF,PGREXT,PCHEXT, &
    PGREXD,PCHEXD,PTYPGR,pxctg,pinod
     


