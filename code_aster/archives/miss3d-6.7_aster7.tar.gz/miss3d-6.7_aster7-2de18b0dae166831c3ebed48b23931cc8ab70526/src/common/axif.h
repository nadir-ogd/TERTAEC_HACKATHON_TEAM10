    parameter (nth=1)
    REAL*8 :: costh,sinth,dtheta
    common /axif/ costh(nth),sinth(nth),dtheta,dlt
