! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                         REPERTOIRE COMMON                            C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
! SAVIN  4/05/98

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                                                                      C
!     COMMON DES POINTEURS POUR LA RESOLUTION GLOBALE DU PROBLEME PAR  C
!     ITERATIONS                                                       C
!                                                                      C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!                                                                      C
!        E. SAVIN                  LMSS/ECP                            C
!                                                                      C
!        REVISION :                                                    C
!                                                                      C
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

!        pciter : facteurs de participation (ddls globaux) iteres
!        pimpgd : impedance du domaine perturbe non inversee
!        iiter  : ordre courant d'iteration
!        niter  : nombre total d'iterations


    INTEGER*8 ::        pciter,pcite0,pimpgd,iiter,niter,nitedf
    common /iter/  pciter,pcite0,pimpgd,iiter,niter
    parameter      (nitedf = 2)

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
