!M  COMMON FLUI
!LATEXBEGIN
!LATEX Donn�es sur les fluides :
!LATEX \begin{itemize}
!LATEX \item \label{XNORF} XNORF : Facteur de normalisation
!LATEX \item \label{XNORFU} XNORFU : Facteur de normalisation
!LATEX \item \label{XNORFT} XNORFT : Facteur de normalisation
!LATEX \item \label{ROF} ROF : densit�
!LATEX \item \label{VCELR} VCELR : c�l�rit� des ondes
!LATEX \item \label{ZSURF} ZSURF : Cote de la surface libre,
!LATEX \item \label{BETAF} BETAF : Amortissement hysteretique
!LATEX \item \label{ETAF} ETAF : Amortissement visqueux
!LATEX \item \label{flnor} flnor : Facteur de normalisation
!LATEX \item \label{KF} KF : Nombre d'onde,
!LATEX \item \label{INVKF} INVKF : inverse du nombre d'onde,
!LATEX \item \label{INVKF2} INVKF2 : INVKF*INVKF
!LATEX \item \label{KIMP} KIMP : contraste d imp�dance
!LATEX \end{itemize}
!LATEXEND
    REAL*8 ::          XNORF,XNORFU,XNORFT,ROF,VCELR,ZSURF,BETAF, &
    flnor,etaf,kimp
    COMPLEX*16       KF,INVKF,INVKF2
    COMMON /FLUI/ KF,INVKF,INVKF2, &
    XNORF,XNORFU,XNORFT,ROF,VCELR,ZSURF,betaf, &
    flnor,etaf,kimp

