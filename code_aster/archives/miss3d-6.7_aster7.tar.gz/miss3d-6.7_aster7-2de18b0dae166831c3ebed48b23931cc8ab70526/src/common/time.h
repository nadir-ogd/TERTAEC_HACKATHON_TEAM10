!M  COMMON TIME�
!LATEXBEGIN
!LATEX Variables pour le retour en temps
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{MAXPTS} MAXPTS :  longueur max du signal
!LATEX \item \label{FN} FN :  frequence d echantillonnees
!LATEX \item \label{CSN} CSN :  signal
!LATEX \item \label{FREQ0} FREQ0 :  premiere frequence
!LATEX \item \label{AMPL} AMPL :  amplitude du signal
!LATEX \item \label{NPTS} NPTS :  nombre de points d'echantillonnage du spectre
!LATEX \item \label{ITYPNL} ITYPNL :  type de signal parmis :
!LATEX                                 ITABUL, IRICKR, ISINUS, IHEAVI, IDIRAC
!LATEX \item \label{ITYPSP} ITYPSP :  Ordre du spectre, parmis :
!LATEX                                ISACC, ISVIT, ISDEP
!LATEX \item \label{LCOR} LCOR : Correction pour avoir un signal d�butant par 0.
!LATEX\end{itemize}
!LATEXEND


! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

    INTEGER*8 :: MAXPTS
    PARAMETER (MAXPTS=8192)
    COMPLEX*16 CSN
    REAL*8 :: FN,FREQ0,AMPL
    INTEGER*8 :: NPTS,ITYPNL,ITYPSP
    LOGICAL :: LCOR
    COMMON /FSIGNL/ FN(MAXPTS),CSN(MAXPTS),FREQ0,AMPL,NPTS,ITYPNL, &
    ITYPSP,LCOR

!LATEXBEGIN
!LATEX Variables pour les filtres appliqu�s lors du retour en temps
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{VFLTR} FN :  fr�quences �chantillonn�es
!LATEX \item \label{FFLTR} FFLTR :  filtre
!LATEX \item \label{AMPFLT} AMPFLT :  amplitude du filtre,
!LATEX \item \label{NFLTR} NFLTR :  nombre de points d'/'echantillonnage du filtre,
!LATEX \item \label{TYPFLT} TYPFLT :  type de filtre parmis :
!LATEX                                 ITABUL, IRICKR, ISINUS, IHEAVI, IDIRAC
!LATEX \item \label{TTYPOP} ITYPOP :  type d'op�ration parmis :
!LATEX                                 IDIVI, IMULT
!LATEX \item \label{ITYPFL} ITYPFL :  Ordre du filtre, parmis :
!LATEX                                ISACC, ISVIT, ISDEP
!LATEX\end{itemize}
!LATEXEND

    REAL*8 :: FFLTR,AMPFLT
    COMPLEX*16 VFLTR
    INTEGER*8 :: NFLTR,TYPFLT,ITYPOP,ITYPFL
    COMMON /FILTER/ VFLTR(MAXPTS),FFLTR(MAXPTS),NFLTR,TYPFLT, &
    ITYPOP,AMPFLT,ITYPFL


!LATEXBEGIN
!LATEX Variables pour le retour en temps.
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{DT} DT : pas de temps,
!LATEX \item \label{NT} NT : nombre de pas de temps,
!LATEX \item \label{LTIME} LTIME : r�ponses temporelles,
!LATEX \item \label{LSPEC} LSPEC : r�ponses en spectre de Fourier,
!LATEX \item \label{TMAX} TMAX : temps maximum,
!LATEX \item \label{TIMDEL} TIMDEL : retard appliqu� au signal d'entr�e,
!LATEX \item \label{DFRQ} DFRQ : pas en fr�quence,
!LATEX \item \label{FMAX} FMAX : fr�quence maximale,
!LATEX \item \label{LABFFT} LABFFT : type de donnee trait�e,
!LATEX\end{itemize}
!LATEXEND

    character*4 :: labfft
    INTEGER*8 :: nt
    REAL*8 :: DT,tmax,timdel
    REAL*8 :: dfrp,fmax
    logical :: ltime,lspec
    COMMON /PRTIM/ DT,NT,tmax,timdel,dfrp,fmax,ltime,lspec,labfft
