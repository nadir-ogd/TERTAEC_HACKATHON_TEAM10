!M  COMMON TAPE
!    dc:21-02-98
!  ajout d'un fichier de sortie .tex
!LATEXBEGIN
!LATEX Unites fortran des fichiers
!LATEX\begin{itemize}
!LATEX \item \label{ITEXT} ITEXT :  fichier de rapport texte
!LATEX \item \label{ISCRE} ISCRE :  ecran
!LATEX \item \label{IIN} IIN :  fichier de donnees principal ASCII
!LATEX \item \label{IOUT} IOUT :  fichier de sortie ( messages ) ASCII
!LATEX \item \label{IUI} IUI :  champs incident BINAIRE
!LATEX \item \label{ILM} ILM :  champs imposes BINAIRE
!LATEX \item \label{ITDM} ITDM :  champs diffractes BINAIRE
!LATEX \item \label{IDO} ID0 :  champs diffractes locaux BINAIRE
!LATEX \item \label{IUG} IUG :  matrice UG BINAIRE
!LATEX \item \label{ITG} ITG :  matrice TG BINAIRE
!LATEX \item \label{IIMPD} IIMPD :  matrice dimpedance
!LATEX \item \label{IFS} IFS :  force sismique equivalente
!LATEX \item \label{ICTR} ICTR :  champ aux points de controle
!LATEX \item \label{IAUX} IAUX :  fichier auxiliaire
!LATEX \item \label{IGEOM} IGEOM :  donnees geometriques
!LATEX \item \label{IPRP} IPRP :  points d integration
!LATEX \item \label{ITUI} ITUI :  champ incident (contraintes)
!LATEX \item \label{IFTOT} IFTOT :  force totale
!LATEX \item \label{IDES} IDES : Fichier resultat utilisateur
!LATEX \item \label{IMVFD} IMVFD : ddl globaux
!LATEX \item \label{IKEXT} IKEXT : impedance exterieures
!LATEX \item \label{IUTOT} IUTOT : champs diffractes totaux
!LATEX \item \label{ITTOT} ITTOT : champs diffractes totaux (contraintes)
!LATEX \item \label{ICTOT} ICTOT :champs diffractes totaux (point de controle)
!LATEX \item \label{IMAIL} IMAIL : definition des domaines
!LATEX \item \label{ICUI} ICUI : champs incidents (point de controle)
!LATEX \item \label{IINA  } IINA   : Fichier de travail pour la boucle sur les frequences
!LATEX \item \label{ISCTR} ISCTR : champs imposes (point de controle)
!LATEX \item \label{ISCTOT} ISCTOT : champs diffractes totaux (point de controle, contraintes)
!LATEX \item \label{ISCUI} ISCUI : champ incident (point de controle, contraintes)
!LATEX \item \label{IMASS} IMASS : matrice de masse
!LATEX \item \label{IRIGI} IRIGI : matrice de rigidite
!LATEX \item \label{IAMOR} IAMOR : matrice d'ammortissement
!LATEX \item \label{IEIGEN} IEIGEN : frequences propres
!LATEX \item \label{IMEIGE} IMEIGE : matrice de masse sur la base des modes propres
!LATEX \item \label{IEIGV} IEIGV : modes propres en fonction des ddl globaux
!LATEX \item \label{IFEIG} IFEIG : forces modales
!LATEX \item \label{IUGF} IUGF : fonctions de Green DOS2M en frequence, deplacements
!LATEX \item \label{ITGF} ITGF : fonctions de Green DOS2M en frequence, contraintes facette verticale
!LATEX \item \label{ITG2F} ITG2F : fonctions de Green DOS2M en frequence, autres contraintes
!LATEX \item \label{IUGS} IUGS : fonctions de Green DOS2M en spectral, deplacements
!LATEX \item \label{ITGS} ITGS : fonctions de Green DOS2M en spectral, contraintes facette verticale
!LATEX \item \label{ICOEF} ICOEF : variables aleatoires associees au developpement de Karhunen-Loeve
!LATEX \item \label{IKDELTA} IKDELTA : matrice de raideur non-projetee sur les modes de KL du domaine heterogene
!LATEX\end{itemize}
!LATEXEND
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
    INTEGER*8 ::  ISCRE,IIN,IOUT,IUI,ILM,ITDM,IUG,ITG,IIMPD,IFS, &
    ICTR,IAUX,IGEOM,IPRP,ITUI,ID0,IDES, &
    IMVFD,ikext,IKAUX,iutot,ittot,ictot,imail,icui, &
    iina  ,isctr,isctot,iscui,iftot,imass,irigi,iamor, &
    irtot,imtot,ieigen,imeige,ieigv,ifeig,lstuni, &
    ikdelta
    INTEGER*8 :: iflchi
    INTEGER*8 :: iugf,itgf,itg2f,iugs,itgs,itext
    INTEGER*8 ::        icttot,iflchp,icoef, &
    iutodv,ittodv,ictodv,icttdv,icext,icsol
    COMMON /TAPE/  ISCRE,IIN,IOUT,IUI,ILM,ITDM,IUG,ITG,IIMPD,IFS, &
    ICTR,IAUX,IGEOM,iprp,ITUI,ID0,IDES, &
    IMVFD,ikext,IKAUX,iutot,ittot,ictot,imail,icui, &
    iina  ,isctr,isctot,iscui,iftot,imass,irigi,iamor, &
    irtot,imtot,ieigen,imeige,ieigv,ifeig,lstuni, &
    iflchi,iugf,itgf,itg2f,iugs,itgs,itext,icttot, &
    icoef,iutodv,ittodv,ictodv,icttdv,icext,icsol, &
    ikdelta
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!LATEXBEGIN
!LATEX FTAPE donnees sur les fichiers.
!LATEX\begin{itemize}
!LATEX \item \label{RFILE} RFILE(100) : type et nom des fichiers
!LATEX\begin{itemize}
!LATEX \item  RFILE...(1:4) STATUS
!LATEX\begin{itemize}
!LATEX \item          'UNKN' UNKNOWN
!LATEX \item               'NEW ' NEW
!LATEX \item               'SCRA' STRATCH
!LATEX\end{itemize}
!LATEX \item   RFILE...(5:6)  ACCES
!LATEX\begin{itemize}
!LATEX \item               'DI' DIRECT
!LATEX \item               'SQ' SEQUENCIEL
!LATEX\end{itemize}
!LATEX \item     RFILE...(7:8)  FORM
!LATEX\begin{itemize}
!LATEX \item               'UN' UNFORMATTED
!LATEX \item               'FO' FORMATTED
!LATEX\end{itemize}
!LATEX \item   RFILE...(9,9) IDENT
!LATEX\begin{itemize}
!LATEX \item                'N' Si ce fichier n'a jamais ete ouvert
!LATEX \item                'Y' Si ce fichier a deja ete ouvert
!LATEX\end{itemize}
!LATEX \item    RFILE...(10,80)  Non du fichier, initialise avec le
!LATEX                           suffixe lors de la premiere ouverture.
!LATEX                            On ajoute le prefixe \GENER.\ISDOM
!LATEX\end{itemize}
!LATEX \item \label{LREC}   LREC      : taille des enregistrements
!LATEX \item \label{LKEY}   lkey      : position courante sur le fichier
!LATEX \item \label{LREWFL} lrewfl    : flag sur le rembobinage
!LATEX \item \label{IFTYP} iftyp      : type de fichier
!LATEX\end{itemize}
!LATEXEND
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
    CHARACTER*80 :: RFILE(100)
    COMMON /FTAPE/  RFILE
    INTEGER*8 ::       LREC(100),LKEY(100),lrewfl(100)
    INTEGER*8 ::      IFTYP(100)
    INTEGER*8 ::       IFRQF(100),irlast(100),nsfrq(100)
    COMMON /FLKEY/  lrec,LKEY,lrewfl,IFRQF,irlast,nsfrq
    COMMON /FTYP/ IFTYP
