!M  COMMON MATE
!LATEXBEGIN
!LATEX donn�es sur les mat�riaux :
!LATEX\begin{itemize}
!LATEX \item \label{RO} RO :  $\rho$ masse volumique
!LATEX \item \label{VP} VP :  $/v_p$ vitesse des ondes P
!LATEX \item \label{VS} VS :  $/v_s$ vitesse des ondes S
!LATEX \item \label{BETA} BETA :  $\beta$ amortissement Hyst�retique
!LATEX \item \label{ETA} ETA :  $\eta$ amortissement visqueux
!LATEX \item \label{KP} KP :  $\omega/v_p$
!LATEX \item \label{KS} KS :  $\omega/v_s$
!LATEX \item \label{XMU} XMU :  $\mu=\rho c_s^2(1-i\beta)$ coefficient de Lame
!LATEX \item \label{XAPA} XAPA :  VS/VP
!LATEX \item \label{XAPA2} XAPA2 :  XAPA**2
!LATEX \item \label{XAPA3} XAPA3 :  XAPA**3
!LATEX \item \label{XAPA22} XAPA22 :  1/XAPA**2-2
!LATEX \item \label{CNORMT} CNORMT :  1/(4*PI)
!LATEX \item \label{CNORMU} CNORMU :  CNORMT/XMU
!LATEX\end{itemize}
!LATEXEND


    REAL*8 ::    RO,VP,VS,BETA,ETA
! dc:29-12-00 : Passage de xmu en complex
    COMPLEX*16 XMU
    REAL*8 ::    XAPA,XAPA2,XAPA3,XAPA22
    COMPLEX*16   CNORMT,CNORMU,KP,KS,INVKP,INVKS,INVKP2,INVKS2
    COMMON /MATE/ CNORMT,CNORMU,XMU,KP,KS,INVKP,INVKS,INVKP2, &
    INVKS2,RO,VP,VS,BETA,ETA,XAPA,XAPA2,XAPA3,XAPA22

