!M  COMMON ADMAIN
!LATEXBEGIN
!LATEX pointeur globaux sur les modules
!LATEX\begin{itemize}
!LATEX \item \label{MTOT} MTOT :  taille du common blanc
!LATEX \item \label{PLAST} PLAST :  premiere adresse libre courant
!LATEX \item \label{PDATA} PDATA :  adresse du bloc data, PDATA vaut 1 ou NMXDOS
!LATEX \item \label{PRESOU} PRESOU :  adresse du bloc equation integrale
!LATEX \item \label{PRESAL} PRESAL :  adresse du bloc resolution globale
!LATEX \item \label{PMVFD} PMVFD :  adresse du bloc mouvement induit
!LATEX \item \label{PDIFF} PDIFF :  adresse du bloc de synthese des champs
!LATEX \item \label{PCALUI} PCALUI :  adresse du bloc champ incident
!LATEX \item \label{PGEOM} PGEOM :  adresse du bloc donnes geometrique
!LATEX \item \label{NGEOM} NGEOM :  taille du bloc donnes geometrique
!LATEX \item \label{PCONTR} PCONTR :  adresse du bloc controle
!LATEX \item \label{PPRPIN} PPRPIN :  adresse du bloc preparation des fonctions de Green
!LATEX \item \label{NPRPIN} NPRPIN :  taille du bloc preparation des fonctions de Green
!LATEX \item \label{PEXDOS} PEXDOS :  adresse du bloc DOS2M
!LATEX \item \label{PPRDOS} PPRDOS :  adresse du bloc de definition DOS2M
!LATEX \item \label{PFIDOM} PFIDOM :  adresse de fin du bloc de definition du domaine courant
!LATEX \item \label{PTMAX} PTMAX :  adresse maximale atteinte dans le common blanc
!LATEX \item \label{PNBUI} PNBUI : adresse des nombres de chargements par domaine,
!LATEX \item \label{NTRIAL} NTRIAL : nombre de tirages de Monte-Carlo
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 ::       MTOT  ,PLAST ,PDATA ,PRESOU,PCALUI,PGEOM ,NGEOM , &
    PCONTR,PPRPIN,NPRPIN,PMVFD , &
    PRESAL,PDIFF,PNBUI,PEXDOS,PFIDOM,PPRDOS, &
    PTMAX,NTRIAL
    COMMON /ADMAIN/ MTOT  ,PLAST ,PDATA ,PRESOU,PCALUI,PGEOM ,NGEOM , &
    PCONTR,PPRPIN,NPRPIN,PMVFD , &
    PRESAL,PDIFF,PNBUI,PEXDOS,PFIDOM,PPRDOS, &
    PTMAX,NTRIAL


