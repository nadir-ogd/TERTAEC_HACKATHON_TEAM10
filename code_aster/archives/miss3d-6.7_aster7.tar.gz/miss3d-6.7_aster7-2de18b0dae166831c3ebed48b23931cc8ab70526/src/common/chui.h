!M  COMMON CHUI
!LATEXBEGIN
!LATEX variable relative au calcul du champ incident
!LATEX\begin{itemize}
!LATEX  \item \label{PXSRUI} PXSCUI(NDIM) : position de la source ponctuelle creant le champ incident
!LATEX  \item \label{PDSRUI} PDSCUI(NDIM) : direction de la source ponctuelle creant le champ incident
!LATEX  \item \label{PDIRSV} PDIRSV(NDIM) : direction de l onde plane SV creant le champ incident
!LATEX  \item \label{PDIRP} PDIRP(NDIM) : direction de l onde plane P creant le champ incident
!LATEX  \item \label{PDIRSH} PDIRSH(NDIM) : direction de l onde plane SH creant le champ incident
!LATEX \item \label{PAMPP} PAMPP : amplitude de l onde plane P creant le champ incident
!LATEX \item \label{PAMPSV} PAMPSV : amplitude de l onde plane SV creant le champ incident
!LATEX \item \label{PAMPSH} PAMPSH : amplitude de l onde plane SH creant le champ incident
!LATEX \item \label{LPLANE} LPLANE : flag sur un champ incident d'ondes planes
!LATEX \item \label{LDPLA} LDPLA : flag sur un champ incident d'ondes planes du demi-espace
!LATEX \item \label{LMI3D} LMI3D : flag sur un champ incident lu sur fichier issu de MISS3D
!LATEX \item \label{FLCHUI} FLCHUI : nom du fichier ou est lu ce champ incident
!LATEX \item \label{NDDLUI} NDDLUI : nombre de ddl par point dans le fichier FLCHUI
!LATEX \item \label{NCHFLI} NCHFLI : nombre de champs incidents dans le fichier FLCHUI
!LATEX\end{itemize}
!LATEXEND
    INTEGER*8 ::   PXSRUI,PDSRUI,PDIRSV,PDIRP,PDIRSH,PAMPP,PAMPSV, &
    PAMPSH
    LOGICAL :: LPLANE,LDPLA,LMI3D,LUINOD
    REAL*8 ::     XNSRF,YNSRF,ZNSRF
    COMMON /CHUI/  XNSRF,YNSRF,ZNSRF,PXSRUI,PDSRUI,PDIRSV,PDIRP, &
    PDIRSH,PAMPP,PAMPSV,PAMPSH,LPLANE,LDPLA,LMI3D, &
    LUINOD
    CHARACTER*80 :: FLCHUI
    INTEGER*8 :: NDDLUI,NCHFLI
    COMMON /FCHUI/ FLCHUI,NDDLUI,NCHFLI


