!M  COMMON ACONT
!LATEXBEGIN
!LATEX
!LATEX variables pour le calcul des champs en des points exterieurs a la surface.
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{PCHCTR} PCHCTR :  Champs aux points de controle
!LATEX \item \label{PU0CTR} PU0CTR : champs ud0 aux points de controle
!LATEX \item \label{PUTCTR} PUTCTR : champs total aux points de controle
!LATEX \item \label{PCUI}   PCUI : champs incident aux points de controle
!LATEX \item \label{PNEPGI} PNEPGI :  coordonnees des normales aux points sources
!LATEX \item \label{PWPGI} PWPGI :  poids de gauss aux points sources
!LATEX \item \label{PELTGI} PELTGI :  numero de l'element des points sources
!LATEX \item \label{PAIREI} PAIREI :  aire des elements sources
!LATEX \item \label{PORDGI} PORDGI :  numero des points source ranges par ordre d'altitude decroissante,
!LATEX \item \label{PNPTGI} PNPTGI :  nombre de points source entre deux niveaux source successif,
!LATEX \item \label{PTTCTR} PTTCTR : champ impose total sur interface volumique
!LATEX \item \label{PWZGI} PWZGI :  coefficients d'interpolation par rapport a l altitude pour les points source,
!LATEX\end{itemize}
!LATEXEND


    INTEGER*8 :: PCHCTR,PU0CTR,putctr,pcui,pttctr
    INTEGER*8 :: pwpgi,peltgi,pnepgi,pairei,pordgi,pnptgi,pwzgi

    COMMON /ACONTR/ PCHCTR,PU0CTR,putctr,pcui,pttctr, &
    pwpgi,peltgi,pnepgi,pairei,pordgi,pnptgi,pwzgi
