!M  COMMON AGEOM
!LATEXBEGIN
!LATEX variable des donnees geometriques
!LATEX\begin{itemize}
!LATEX \item \label{PXCDG} PXCDG :  coordonnes du centre de gravite des elements INGEOM
!LATEX \item \label{PXSLOC} PXSLOC :  coordonnees des sources symetrisees
!LATEX \item \label{PCHLME} PCHLME :  champs imposes par elements INGEOM
!LATEX \item \label{PAIRE} PAIRE :  aire des elements INGEOM
!LATEX \item \label{PNAIRE} PNAIRE :  normale*aire des elements
!LATEX \item \label{PELEL} PELEL :  pointeur elements-element
!LATEX \item \label{PNOREL} PNOREL :  normale moyenne des elements
!LATEX \item \label{PXPGG} PXPGG :  coordonnees des points de gauss grossiers INGEOM
!LATEX \item \label{PNEPGG} PNEPGG :  coordonnees des normales aux points de gauss grossiers
!LATEX \item \label{PWPGG} PWPGG :  poids de gauss aux points de gauss grossiers
!LATEX \item \label{PELTGG} PELTGG :  numero de l'element des points de gauss grossiers
!LATEX \item \label{PXPGF} PXPGF :  coordonnees des points de gauss fin
!LATEX \item \label{PNEPGF} PNEPGF :  coordonnees des normales aux points de gauss     fin
!LATEX \item \label{PWPGF} PWPGF :  poids de gauss  aux points de gauss     fin
!LATEX \item \label{PELTGF} PELTGF :  numero de l'element des points de gauss     fin
!LATEX \item \label{PGEO} PDIAG :  donnees geometriques des elements particuliers (plaque, poutres)
!LATEX \item \label{PEXCHE} PEXCHE :  indice min et max des champs
!LATEX \item \label{PMAIRE} PMAIRE :  aire de l'element sur lequel porte le ddl
!LATEX \item \label{PIDDLC} PIDDLC :  pointeur vers la numerotation locale des ddls
!LATEX \item \label{ITYCHE} ITYCHE :  type de la matrice des champs imposes
!LATEX\end{itemize}
!LATEXEND
! MLElHabre, 23/04/98 : ajout de pxsloc

    INTEGER*8 ::     PXCDG ,PCHLME,PAIRE ,PNOREL, &
    PXPGG ,PNEPGG,PWPGG ,PELTGG,PXPGF ,PNEPGF,PWPGF , &
    PELTGF,pgeo,pexche,pmaire,piddlc,pxsloc, &
    pnaire,pelel

    INTEGER*8 ::     ityche
    INTEGER*8 ::         pelkl,nelkl

    COMMON /AGEOM/  PXCDG ,PCHLME,PAIRE ,PNOREL, &
    PXPGG ,PNEPGG,PWPGG ,PELTGG,PXPGF ,PNEPGF,PWPGF , &
    PELTGF,pgeo,pexche,pmaire,piddlc,ityche,pxsloc, &
    pnaire,pelel,pelkl,nelkl

