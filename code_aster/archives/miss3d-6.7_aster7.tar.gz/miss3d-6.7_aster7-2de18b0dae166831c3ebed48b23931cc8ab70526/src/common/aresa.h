!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{PIMPTV} PIMPTV :  matrice d'impedance locales
!LATEX \item \label{PS2MTV} PS2MTV :  forces sismiques locales
!LATEX \item \label{PIMPG} PIMPG :  impedance globale
!LATEX \item \label{PFORCG} PFORCG :  force sismique globale
!LATEX \item \label{PS2MEX} PS2MEX :  second membre du aux champs exterieurs
!LATEX \item \label{PMASSG} pmassg : matrice de masse globale
!LATEX \item \label{PRIGG} PRIGG :  matrice de rigidite globale
!LATEX \item \label{PEIGEN} PEIGEN :  frequences propres
!LATEX \item \label{PEIGV} PEIGV :  vecteurs propres
!LATEX \item \label{PMEIG} PMEIG :  masse modale
!LATEX \item \label{PFEIG} PFEIG :  force modale
!LATEX \item \label{PSYS} PSYS :  matrice a diagonaliser
!LATEX \item \label{PS2MMC} PS2MMC : MOYENNE    RESOLUTION MONTE-CARLO
!LATEX \item \label{PS2DEV} PS2DEV: COVARIANCE RESOLUTION MONTE-CARLO
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 ::        PIMPTV,PS2MTV,PIMPG,PFORCG,PS2MEX, &
    PMASSG,PRIGG,PEIGEN,PEIGV,PMEIG,PFEIG,PSYS, &
    PS2MMC,PS2DEV
    COMMON /ARESA/ PIMPTV,PS2MTV,PIMPG,PFORCG,PS2MEX, &
    PMASSG,PRIGG,PEIGEN,PEIGV,PMEIG,PFEIG,PSYS, &
    PS2MMC,PS2DEV
