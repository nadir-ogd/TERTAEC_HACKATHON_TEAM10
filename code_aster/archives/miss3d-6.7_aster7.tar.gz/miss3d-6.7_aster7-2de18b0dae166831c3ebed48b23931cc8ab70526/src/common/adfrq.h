!M  COMMON ADFRQ
!LATEXBEGIN
!LATEX Variables pour le chargement d une plage de frequence
!LATEXEND
    INTEGER*8 ::         pfreq,pnamfr,plpfrq,pdbpfr,pvfreq,porpfr,plfrq, &
    pstpfr,pcfrq,plcfrq
    COMMON /ADFRQ/  pfreq,pnamfr,plpfrq,pdbpfr,pvfreq,porpfr,plfrq, &
    pstpfr,pcfrq,plcfrq
