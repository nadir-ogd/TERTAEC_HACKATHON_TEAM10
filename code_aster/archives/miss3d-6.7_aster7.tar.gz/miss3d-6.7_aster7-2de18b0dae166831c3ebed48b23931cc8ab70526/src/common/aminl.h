    INTEGER*8 :: pdunl,punl,punlm,pfsnl,pdfsm, &
    pfo,pfs,pindex,pfact,pnbv
    common /aminl/  pdunl,punl,punlm,pfsnl,pdfsm, &
    pfo,pfs,pindex,pfact,pnbv
