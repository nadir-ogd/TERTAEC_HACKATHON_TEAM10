!LATEXBEGIN
!LATEX      Les common de dos2m utiles a miss
!LATEXEND
    include '../common/aindos.h'
    include '../common/dos2m/datpb.h'
    include '../common/dos2m/horiz.h'
    include '../common/dos2m/spec.h'
