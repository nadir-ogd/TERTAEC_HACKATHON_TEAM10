"""
This module provides basic functions to check values from Miss files.
"""

import numpy


def almost_equal(calculated, reference, epsilon):
    """Check that a calculated value is almost equal to a reference value.

    It checks that:
        abs(calculated - reference) <= abs(reference) * epsilon

    Arguments:
        calculated (float): The calculated value.
        reference (float): The reference value.
        epsilon (float): Maximal difference.

    Returns:
        bool: *True* if the calculated value is almost equal to the reference,
        *False* otherwise.
    """
    return abs(calculated - reference) <= abs(reference) * epsilon


def check_complex_values(filename, points, skiprows=2, epsilon=0.001):
    """Compare values from filename to the given points.

    Arguments:
        filename (str): Path to file containing 3 columns (after title lines).
        points (list): List expected values as couples of (absc, complex).
        skiprows (int): Number of title lines (default: 2).
        epsilon (float): Tolerance (default: 0.001).
    """

    def _cmp(x0, absc, ordo, refe):
        fmt_ok = " OK  {0} ; para={1}; value={2}"
        fmt_nook = "NOOK {0} ; para={1}; value={2} != {3} (epsilon {4})"
        value = numpy.interp(x0, absc, ordo)
        valid = almost_equal(value, refe, epsilon=epsilon)
        if valid:
            print(fmt_ok.format(filename, x0, value))
        else:
            print(fmt_nook.format(filename, x0, value, refe, epsilon))
        return valid

    values = numpy.loadtxt(filename, skiprows=skiprows)
    freq, real, imag = values.transpose()[:3]

    checked = True
    for x0, cmplx in points:
        checked = _cmp(x0, freq, real, cmplx.real) and checked
        checked = _cmp(x0, freq, imag, cmplx.imag) and checked
    assert checked, "checking values failed"
