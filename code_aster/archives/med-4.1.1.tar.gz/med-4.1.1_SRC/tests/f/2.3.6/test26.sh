${EXECDIR}/test26 > /dev/null 2>&1
