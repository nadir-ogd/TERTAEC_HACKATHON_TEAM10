${EXECDIR}/test7 > /dev/null 2>&1
