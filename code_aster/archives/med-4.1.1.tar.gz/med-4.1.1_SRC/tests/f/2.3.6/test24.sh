${EXECDIR}/test24 > /dev/null 2>&1
