${EXECDIR}/test13 test12.med > /dev/null 2>&1
