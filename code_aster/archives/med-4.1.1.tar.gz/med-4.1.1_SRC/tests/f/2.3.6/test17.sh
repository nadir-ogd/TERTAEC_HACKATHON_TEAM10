${EXECDIR}/test17 > /dev/null 2>&1
