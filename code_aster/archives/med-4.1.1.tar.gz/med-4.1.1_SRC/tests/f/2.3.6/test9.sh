${EXECDIR}/test9 > /dev/null 2>&1
