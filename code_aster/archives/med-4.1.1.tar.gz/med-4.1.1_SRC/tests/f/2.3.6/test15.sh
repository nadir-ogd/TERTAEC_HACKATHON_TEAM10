${EXECDIR}/test15 test14.med > /dev/null 2>&1
