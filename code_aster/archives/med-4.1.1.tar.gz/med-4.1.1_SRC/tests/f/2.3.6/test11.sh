${EXECDIR}/test11 > /dev/null 2>&1
