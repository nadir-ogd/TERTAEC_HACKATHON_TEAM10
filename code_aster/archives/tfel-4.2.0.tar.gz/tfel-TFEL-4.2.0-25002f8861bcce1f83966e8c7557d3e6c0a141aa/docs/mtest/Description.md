The `@Description` keywords describes the test which is implemented in
a mtest file.

This keyword is followed by a block containing all the relevant piece
of information.

## Example

~~~~ {.cpp}
@Description
{
  "Modélisation d'un tube sous pression"
}
~~~~~~~~
