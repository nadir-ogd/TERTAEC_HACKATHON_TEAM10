The `@MaximalTimeStep` keyword let the user define the maximal time
step allowed.

This keyword is followed by a value.

## Example

~~~~ {.cpp}
@MaximalTimeStep 1.e-4;
~~~~
