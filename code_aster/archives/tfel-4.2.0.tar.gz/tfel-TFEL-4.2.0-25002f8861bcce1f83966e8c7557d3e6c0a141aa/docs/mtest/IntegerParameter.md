The `@IntegerParameter` keyword specifies the value of an integer
parameter of the behaviour.

## Example

~~~~ {.cpp}
@IntegerParameter 'iter' 12;
~~~~~~~~

