The `@UnsignedIntegerParameter` keyword specifies the value of a
parameter of the behaviour.

## Example

~~~~ {.cpp}
@UnsignedIntegerParameter 'iterMax' 12;
~~~~~~~~
