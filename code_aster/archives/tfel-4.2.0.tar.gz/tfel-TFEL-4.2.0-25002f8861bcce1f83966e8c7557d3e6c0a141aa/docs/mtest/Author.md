The `@Author` keyword is used give the name of the person who wrote
the mtest file.

All the following words are appended to the author's name up to a
final semi-colon.

## Example:

~~~~ {.cpp}
@Author Éric Brunon;
~~~~~~~~
