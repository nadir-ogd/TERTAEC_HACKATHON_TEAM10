The `@Print` keyword is an alias to the `@Message` keyword.

## Example:

~~~~ {.cpp}
@Print "12*5";
~~~~~~~~
