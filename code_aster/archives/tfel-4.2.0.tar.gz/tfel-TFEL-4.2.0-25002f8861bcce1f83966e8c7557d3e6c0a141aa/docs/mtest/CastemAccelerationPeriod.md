The keyword `@CastemAccelerationPeriod` specifies the number of
iterations between two calls to the acceleration algorithm.

This keyword is followed by a positive number.

## Example

~~~~ {.cpp}
@CastemAccelerationPeriod 3;
~~~~~~~~
