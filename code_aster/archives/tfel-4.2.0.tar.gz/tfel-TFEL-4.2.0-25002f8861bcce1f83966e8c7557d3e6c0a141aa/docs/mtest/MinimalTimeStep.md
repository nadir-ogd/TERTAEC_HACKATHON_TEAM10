The `@MinimalTimeStep` keyword let the user define the minimal time
step allowed.

This keyword is followed by a value.

## Example

~~~~ {.cpp}
@MinimalTimeStep 1.e-4;
~~~~
