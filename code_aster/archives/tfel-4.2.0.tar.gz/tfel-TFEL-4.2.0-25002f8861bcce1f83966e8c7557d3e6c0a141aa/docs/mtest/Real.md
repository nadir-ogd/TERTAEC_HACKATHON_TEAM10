The `@Real` keyword let the user define a constant.

This keyword is followed by the name of the constant, as a string and
by the value of the constant.

## Example

~~~~ {.cpp}
@Real 'SXX0' 20.6;
~~~~
