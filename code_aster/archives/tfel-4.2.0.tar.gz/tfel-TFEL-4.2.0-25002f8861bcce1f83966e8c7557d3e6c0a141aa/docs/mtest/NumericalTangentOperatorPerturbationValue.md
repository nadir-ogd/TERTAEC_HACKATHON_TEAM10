The `@NumericalTangentOperatorPerturbationValue` keyword can be used
to adjust the value use to perform a numerical approximation of the
tangent operator. This keyword followed by the value to be used.

## Example

~~~~ {.cpp}
@NumericalTangentOperatorPerturbationValue 1.e-9;
~~~~~~~~
