The `@DynamicTimeStepScaling` keyword let the user enable or disable
the dynamic time step adaptation.

This keyword is followed by a boolean.

## Example

~~~~ {.cpp}
@DynamicTimeStepScaling true;
~~~~
