The `@ResidualFile` let the user specify the name of a file where the
residuals at each iteration will be printed.

## Example

~~~~ {.cpp}
@ResidualFile 'residual.res';
~~~~
