The `@Date` keyword allows the user to precise when the mtest file was
written.

All the following words are appended to the date up to a final
semi-colon.

## Example

~~~~ {.cpp}
@Date 2008-11-17;
~~~~~~~~
