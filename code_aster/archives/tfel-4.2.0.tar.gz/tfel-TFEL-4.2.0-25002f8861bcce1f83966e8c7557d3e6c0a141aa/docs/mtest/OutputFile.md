The `@OutputFile` keywords specifies the name of the output file. By
default, the name of output file is egal to the name of the input
file, minus the `.mtest` extension if present, plus `.res`.

## Example

~~~~ {.cpp}
@OutputFile 'results.txt';
~~~~~~~~
