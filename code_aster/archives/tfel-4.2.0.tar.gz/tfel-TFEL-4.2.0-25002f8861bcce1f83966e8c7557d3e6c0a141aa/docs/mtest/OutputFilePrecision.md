The `@OutputFilePrecision` specify the number of digits used to print
the results in the output file.

This keyword is followed by the number of digits wanted.

## Example

~~~~ {.cpp}
@OutputFilePrecision 15;
~~~~~~~~
