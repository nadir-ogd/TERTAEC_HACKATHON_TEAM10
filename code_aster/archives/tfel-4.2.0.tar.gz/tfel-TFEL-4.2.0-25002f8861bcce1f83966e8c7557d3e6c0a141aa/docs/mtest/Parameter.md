The `@Parameter` keyword specifies the value of a parameter of the
behaviour.

## Example

~~~~ {.cpp}
@Parameter 'espilon' 1.e-8;
~~~~~~~~

