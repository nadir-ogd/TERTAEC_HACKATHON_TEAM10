The `Output` keyword changes the name of the output variable. By
default, this name is `res`. This keyword is followed by the new name
of the output variable.

## Example

~~~~{.cpp}
@Output b ;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
