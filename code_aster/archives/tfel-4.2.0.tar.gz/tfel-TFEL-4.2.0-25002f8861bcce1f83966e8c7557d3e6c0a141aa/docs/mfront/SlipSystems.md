The `@SlipSystems` can be use to define several families of slip
systems. This keyword is followed by an array defining the various
slip systems. The user can refer to the description of the
`@SlipSystem` keyword for a detailed description.
