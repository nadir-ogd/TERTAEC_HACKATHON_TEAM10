The `@ExternalStateVar` keyword is a deprecated synonymous of
`@ExternalStateVariable`.
