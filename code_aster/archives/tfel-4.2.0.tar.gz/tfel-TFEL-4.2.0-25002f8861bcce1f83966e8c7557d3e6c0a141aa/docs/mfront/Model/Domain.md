The `@Domain` let the user define the default domain on which a model
shall be applied. This keyword is followed by the name of the domain.

This keyword is deprecated as domains shall be explicitely specified
by specialisation.

## Example

~~~~{.cpp}
@Domain "Fuel";
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
