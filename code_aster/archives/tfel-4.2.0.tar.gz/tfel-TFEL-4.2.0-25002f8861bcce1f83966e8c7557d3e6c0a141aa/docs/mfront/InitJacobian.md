The `@InitJacobian` keyword is a deprecated synonymous of
`@InitializeJacobian`.
