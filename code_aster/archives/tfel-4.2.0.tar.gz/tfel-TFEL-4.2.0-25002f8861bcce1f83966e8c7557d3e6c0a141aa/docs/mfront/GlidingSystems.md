An synonymous of `@SlipSystems`.
See `@SlipSystems` for details.
