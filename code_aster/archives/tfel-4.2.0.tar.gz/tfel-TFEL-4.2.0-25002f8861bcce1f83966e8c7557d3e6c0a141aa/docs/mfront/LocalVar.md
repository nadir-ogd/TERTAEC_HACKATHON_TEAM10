The `@LocalVar` keyword is a deprecated synonymous of
`@LocalVariable`.
