An synonymous of `@SlipSystem`.
See `@SlipSystem` for details.
