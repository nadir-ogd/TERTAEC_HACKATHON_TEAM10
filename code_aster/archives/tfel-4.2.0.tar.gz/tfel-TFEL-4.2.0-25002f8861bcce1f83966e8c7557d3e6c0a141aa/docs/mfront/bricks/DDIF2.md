The `DDIF2` brick is build upon the `DDIF2` stress potential.
