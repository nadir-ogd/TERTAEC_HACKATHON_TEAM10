The `StandardElasticity` brick is build upon the `Hooke` stress potential.

## Example

~~~~{.cpp}
@Brick "StandardElasticity";
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
