The `@StateVar` keyword is a deprecated synonymous of
`@StateVariable`.
