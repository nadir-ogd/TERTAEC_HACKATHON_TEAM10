The `@Coef` keyword is a deprecated synonymous of
`@MaterialProperty`.
