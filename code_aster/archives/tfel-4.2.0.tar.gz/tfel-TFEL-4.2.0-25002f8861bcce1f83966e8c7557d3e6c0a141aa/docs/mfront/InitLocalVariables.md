The `@InitLocalVariables` keyword is a deprecated synonymous of
`@InitializeLocalVariables`.
