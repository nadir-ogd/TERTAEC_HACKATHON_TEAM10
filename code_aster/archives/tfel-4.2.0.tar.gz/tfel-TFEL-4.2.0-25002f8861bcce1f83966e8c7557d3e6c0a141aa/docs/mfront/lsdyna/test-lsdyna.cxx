/*!
 * \file   test-lsdyna.cxx
 * \brief
 * \author th202608
 * \date   14/06/2018
 */

#include <cstdlib>
#include "mfront-lsdyna.cxx"

int main() {
  lsdyna::BehaviourLoader l;
  return EXIT_SUCCESS;
}  // end of main
