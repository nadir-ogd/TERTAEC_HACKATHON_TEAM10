The `@JacobianComparisonCriterium` keyword is a deprecated synonymous
of `@JacobianComparisonCriterion`.
