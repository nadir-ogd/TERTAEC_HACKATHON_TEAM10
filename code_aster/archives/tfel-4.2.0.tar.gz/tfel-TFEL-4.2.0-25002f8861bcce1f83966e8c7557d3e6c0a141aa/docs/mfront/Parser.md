The `@Paser` keyword is a deprecated synonymous of `@DSL`.
