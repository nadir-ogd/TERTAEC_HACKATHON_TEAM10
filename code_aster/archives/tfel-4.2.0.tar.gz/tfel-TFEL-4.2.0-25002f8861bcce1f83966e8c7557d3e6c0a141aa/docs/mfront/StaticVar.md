The `@StaticVar` keyword is a deprecated synonymous of
`@StaticVariable`.
