The `@IterMax` keyword is a deprecated synonymous of
`@MaximumNumberOfIterations`.
