The `@InitJacobianInvert` keyword is a deprecated synonymous of
`@InitializeJacobianInvert`.
