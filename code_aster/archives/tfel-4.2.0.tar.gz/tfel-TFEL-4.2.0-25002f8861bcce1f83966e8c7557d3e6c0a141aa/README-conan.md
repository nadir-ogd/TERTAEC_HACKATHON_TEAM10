
~~~~{.bash}
$ conan remote add bincrafters https://api.bintray.com/conan/bincrafters/public-conan
$ conan install 
~~~~
