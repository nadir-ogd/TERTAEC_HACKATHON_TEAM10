# PETSc - Third party tools

This repository publishes archives of third party tools needed to
build [PETSc] for [code_aster].

Original PETSc source files can be found [on gitlab.com][PETSc]
or from [its intranet mirror][PETSc_intranet].

The [download_3rd_tools](./download_3rd_tools.py) script automatically downloads
the archives of the third party tools using the PETSc configuration scripts.

Example:

```shell
cd ../petsc
git checkout v3.19.5
cd ../petsc-3rd
./download_3rd_tools.py
```

[code_aster]: http://www.code-aster.org
[PETSc]: https://gitlab.com/petsc/petsc
[PETSc_intranet]: ../petsc
