#!/usr/bin/env python3

"""
    # configure the proxy if necessary
    ./download_3rd_tools.py [--help]

Download 3rd party tools.
"""

import argparse
import re
import shutil
import sys
import tarfile
from pathlib import Path
from subprocess import run
from unittest.mock import MagicMock

HERE = Path(sys.argv[0]).parent


# real Framework needs too much configuration, mock should be sufficient
framework = MagicMock()


def parse_args():
    """Parse the command line arguments."""
    parser = argparse.ArgumentParser(
        usage=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "-n",
        "--dry-run",
        dest="dry",
        action="store_true",
        default=False,
        help="do not download any packages",
    )
    parser.add_argument(
        "--petsc-src",
        dest="src",
        action="store",
        default="../petsc",
        help="path to the PETSc repository",
    )
    parser.add_argument(
        "--dest",
        action="store",
        default="3rd",
        help="destination of the archives",
    )
    return parser.parse_args()


class DownloadHelper:
    """Download PETSc third-party tools."""

    def __init__(self, options) -> None:
        self._dry = options.dry
        self._dest = options.dest
        self._versstr = ["", "# for the VERSION file of codeaster-prerequisites"]
        pkg = Path(options.src) / "config" / "BuildSystem"
        sys.path.append(str(pkg.absolute()))

    def download(self, url, target=None):
        """Download archive using wget."""
        dest = Path(self._dest)
        if not target:
            target = Path(url).name
        cmd = ["wget", "-O", str(dest / target), url]
        print("+ command line:\n  ", " ".join(cmd))
        if not self._dry:
            run(cmd)

    def run(self):
        """main"""
        from config.packages import SuperLU, hpddm, hypre, ml, slepc, sowing

        cfg = hypre.Configure(framework)
        url = cfg.download[-1]
        self.download(url, "hypre_" + Path(url).name)
        self._versstr.append(f'_HYPRE="{cfg.gitcommit}"')

        cfg = hpddm.Configure(framework)
        url = cfg.download[-1]
        self.download(url, "hpddm_" + Path(url).name)
        self._versstr.append(f'_HPDDM="{cfg.gitcommit}"')

        cfg = ml.Configure(framework)
        url = cfg.download[-1]
        self.download(url)
        self._versstr.append(f'_ML="{cfg.gitcommit}"')

        cfg = SuperLU.Configure(framework)
        url = cfg.download[-1]
        self.download(url, "SuperLU_" + Path(url).name)
        self._versstr.append(f'_SUPERLU="{cfg.gitcommit}"')

        cfg = slepc.Configure(framework)
        url = cfg.download[-1]
        self.download(url)
        self._versstr.append(f'_SLEPC="{cfg.gitcommit}"')
        self.download_arpack()

        cfg = sowing.Configure(framework)
        url = cfg.download[-1]
        self.download(url, "sowing_" + Path(url).name)
        self._versstr.append(f'_SOWING="{cfg.gitcommit}"')

        self._versstr.sort()
        print("\n".join(self._versstr))

    def download_arpack(self):
        """Extract info from SLEPc"""
        arch = list(Path("3rd").glob("slepc*.tar.gz"))
        arch = arch[0]
        root = arch.absolute().name.replace(".tar.gz", "")
        tar = tarfile.open(arch)
        tar.extract(f"{root}/config/packages/arpack.py")
        path = f"{root}/config/packages/arpack.py"
        text = ["class Dummy:", "  def __init__(self):"]
        expr = re.compile("^(?P<init> *def __init__.*?) +def ", re.M | re.DOTALL)
        with open(path) as fobj:
            content = fobj.read()
        mat = expr.search(content)
        lines = [i for i in mat.group("init").splitlines() if "=" in i]
        text.extend(lines)
        text.append("info = Dummy()")
        context = {}
        exec(compile("\n".join(text), "__inline__", "exec"), context)
        info = context["info"]
        self.download(info.url, "arpack_" + Path(info.url).name)
        self._versstr.append(f'_ARPACK="{info.version}"')
        shutil.rmtree(root)

if __name__ == "__main__":
    args = parse_args()
    job = DownloadHelper(args)
    job.run()
